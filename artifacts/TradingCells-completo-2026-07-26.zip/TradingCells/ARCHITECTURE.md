# Arquitectura

El mod se organiza por funcionalidades verticales. Cada feature puede contener
dominio, aplicacion y adaptadores, pero las dependencias solo apuntan hacia el
interior.

## Capas

- `domain`: reglas y transiciones puras de Java. No conoce Minecraft, NeoForge,
  configuracion global, NBT ni pantallas.
- `application`: coordina reglas de dominio y puertos. Recibe dependencias por
  constructor y no conoce adaptadores ni APIs de Minecraft.
- `adapters`: traduce entidades, inventarios, NBT, menus, renderizado y eventos
  de Minecraft hacia los servicios de aplicacion.
- `platform/neoforge`: arranque, configuracion, red, registro global y
  composicion entre features.

Cada servicio de aplicacion implementa un puerto `application/port/input`. Los
adaptadores dependen de ese puerto; solamente `FeatureComposition` crea los
servicios concretos y les inyecta `MachineSettingsPort`.

El task `checkArchitecture` valida estos limites, la correspondencia entre
paquete y carpeta, las dependencias entre features y la ausencia de GameTests
en `src/main`.

## Features

| Feature | Responsabilidad |
| --- | --- |
| `captures` | Capturadores, datos de entidades capturadas y representacion cliente. |
| `villagertrading` | Reglas y adaptadores compartidos de profesion, POI, ofertas y descuentos. |
| `tradecages` | Comercio manual de aldeanos y trueque de piglins. |
| `autotrader` | Seleccion, ejecucion y sincronizacion de intercambios automaticos. |
| `breeders` | Reglas de alimentos, coste y tiempo de cria. |
| `incubators` | Crecimiento de entidades capturadas. |
| `farmer` | Ciclo de cultivo, fortuna y eficiencia. |
| `converter` | Estados de infeccion, curacion y descuento. |
| `ironfarm` | Produccion, multiplicadores y animacion temporal. |
| `milkcookie` | Creacion y registro de la galleta con leche. |
| `machines` | Puertos y reglas compartidas por maquinas temporizadas. |

`captures`, `machines` y `villagertrading` son nucleos compartidos. Las demas
features no pueden depender unas de otras. El acceso Minecraft a capturas se
realiza exclusivamente mediante `captures/adapters/api/CapturedMobStackAdapter`;
los items capturadores concretos permanecen privados a su feature.

Una feature no necesita carpetas vacias para todas las capas. `captures` no
tiene `application` porque actualmente no coordina ningun caso de uso: su
dominio solo identifica el tipo capturado y sus adaptadores traducen
ItemStack/NBT/entidades de Minecraft mediante una API anticorrupcion. Si se
anade un flujo propio de captura o liberacion con reglas coordinadas, ese flujo
debera introducir entonces un puerto de entrada y un servicio de aplicacion.

`machines` tampoco representa una maquina registrable. Es el nucleo compartido
para procesos temporizados: `TimedProcess` modela avance, pausa, reinicio y
finalizacion; `MachineSettingsPort` expone configuracion a los servicios sin
acoplarlos a NeoForge. Mantenerlo separado evita copiar estas reglas en cada
feature y evita dependencias laterales entre maquinas concretas.

## Estado y compatibilidad

Los adaptadores son los unicos propietarios de NBT, slots y entidades proxy.
Los servicios calculan decisiones, pero no escriben el mundo. Los IDs de
registro y las claves NBT existentes se conservan; mover una clase Java entre
features no cambia los datos persistidos.

La configuracion se expone mediante `MachineSettingsPort`. NeoForge instala su
adaptador durante el arranque y `FeatureComposition` compone los casos de uso.
Las entidades de bloque no construyen servicios ni leen la configuracion
directamente. No existe un localizador global dentro de dominio o aplicacion.

## Pruebas

Las pruebas de reglas deben ser puras o vivir fuera de `src/main`. Nunca se debe
registrar un `GameTestInstance` de codigo en el mod de produccion: el cliente
intenta serializar ese registro al entrar en un mundo integrado.
