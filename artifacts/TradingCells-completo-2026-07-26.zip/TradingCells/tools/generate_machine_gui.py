from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw


ROOT = Path(__file__).resolve().parents[1] / "src/main/resources/assets/trading_cells/textures/gui"
BACKGROUNDS = ROOT / "machines" / "backgrounds"
MACHINE_SLOTS = ROOT / "sprites" / "machines" / "slots"
CAPTURES = ROOT / "sprites" / "captures"
WIDTH = 204
HEIGHT = 212

PALETTES = {
    "villager_breeder": (0x4A2E17, 0x8B5B2C, 0xD8A75D, 0xC18A4B),
    "piglin_breeder": (0x4B101C, 0x8B2337, 0xD15A68, 0xB64858),
    "converter": (0x28433A, 0x4E7463, 0x91B79E, 0x729984),
    "farmer": (0x3A4215, 0x6D7A25, 0xA6B94A, 0x879838),
    "villager_incubator": (0x624214, 0xA87520, 0xF0C553, 0xC79838),
    "piglin_incubator": (0x551526, 0x932A43, 0xDC6679, 0xB94860),
    "iron_farm": (0x34383B, 0x62686C, 0xAEB5B9, 0x858C90),
}


def rgba(rgb: int, alpha: int = 255) -> tuple[int, int, int, int]:
    return ((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF, alpha)


def panel(
    draw: ImageDraw.ImageDraw,
    bounds: tuple[int, int, int, int],
    dark: tuple[int, int, int, int],
    mid: tuple[int, int, int, int],
    light: tuple[int, int, int, int],
    inner: tuple[int, int, int, int],
) -> None:
    left, top, right, bottom = bounds
    draw.rectangle(bounds, fill=dark)
    draw.line((left, top, right, top), fill=light)
    draw.line((left, top, left, bottom), fill=light)
    if right - left > 2 and bottom - top > 2:
        draw.rectangle((left + 1, top + 1, right - 1, bottom - 1), fill=mid)
        draw.rectangle((left + 2, top + 2, right - 2, bottom - 2), fill=inner)
    draw.line((left, bottom, right, bottom), fill=dark)
    draw.line((right, top, right, bottom), fill=dark)


def machine_background(colors: tuple[int, int, int, int]) -> Image.Image:
    dark, mid, light, inner = map(rgba, colors)
    image = Image.new("RGBA", (WIDTH, HEIGHT), dark)
    draw = ImageDraw.Draw(image)

    draw.rectangle((1, 1, WIDTH - 2, HEIGHT - 2), fill=light)
    draw.rectangle((2, 2, WIDTH - 3, HEIGHT - 3), fill=mid)
    draw.rectangle((3, 3, WIDTH - 4, HEIGHT - 4), outline=dark)

    panel(draw, (6, 4, WIDTH - 7, 19), dark, mid, light, rgba(colors[3]))
    panel(draw, (3, 21, WIDTH - 4, 117), dark, mid, light, mid)
    panel(draw, (28, 119, WIDTH - 5, 132), dark, mid, light, mid)
    panel(draw, (28, 133, WIDTH - 5, HEIGHT - 1), dark, mid, light, mid)
    panel(draw, (3, 114, 25, 208), dark, mid, light, mid)
    return image


def villager_head() -> Image.Image:
    image = Image.new("RGBA", (16, 16))
    draw = ImageDraw.Draw(image)
    outline = (55, 48, 43, 230)
    skin = (142, 128, 116, 180)
    detail = (75, 66, 59, 225)
    nose = (113, 99, 88, 210)

    draw.rectangle((4, 2, 11, 12), fill=outline)
    draw.rectangle((3, 5, 12, 9), fill=outline)
    draw.rectangle((4, 3, 11, 11), fill=skin)
    draw.point((3, 6), fill=skin)
    draw.point((12, 6), fill=skin)
    draw.line((5, 6, 10, 6), fill=detail)
    draw.point((5, 7), fill=detail)
    draw.point((10, 7), fill=detail)
    draw.rectangle((7, 7, 8, 11), fill=outline)
    draw.rectangle((7, 8, 8, 10), fill=nose)
    return image


def piglin_head() -> Image.Image:
    image = Image.new("RGBA", (16, 16))
    draw = ImageDraw.Draw(image)
    outline = (62, 45, 48, 230)
    skin = (151, 112, 120, 180)
    detail = (77, 57, 61, 225)
    snout = (128, 88, 98, 205)

    draw.rectangle((3, 3, 12, 12), fill=outline)
    draw.rectangle((2, 5, 13, 8), fill=outline)
    draw.rectangle((4, 4, 11, 11), fill=skin)
    draw.point((2, 6), fill=skin)
    draw.point((13, 6), fill=skin)
    draw.point((5, 7), fill=detail)
    draw.point((10, 7), fill=detail)
    draw.rectangle((5, 8, 10, 11), fill=outline)
    draw.rectangle((6, 9, 9, 10), fill=snout)
    draw.point((6, 10), fill=detail)
    draw.point((9, 10), fill=detail)
    return image


def outline_sprite(kind: str) -> Image.Image:
    image = Image.new("RGBA", (16, 16))
    draw = ImageDraw.Draw(image)
    ink = (27, 27, 27, 220)

    if kind == "hoe":
        draw.line((4, 2, 11, 2, 11, 4, 8, 4), fill=ink)
        draw.line((8, 3, 5, 6, 5, 8, 3, 10, 3, 13), fill=ink)
    elif kind == "wheat_seeds":
        draw.arc((3, 3, 8, 9), 35, 235, fill=ink)
        draw.arc((7, 5, 12, 11), 35, 235, fill=ink)
        draw.arc((4, 8, 9, 14), 35, 235, fill=ink)
        draw.point((7, 5), fill=ink)
        draw.point((11, 7), fill=ink)
        draw.point((8, 10), fill=ink)
    elif kind == "weakness_potion":
        points = ((6, 2), (9, 2), (9, 4), (10, 5), (11, 8), (11, 12),
                  (10, 13), (5, 13), (4, 12), (4, 8), (5, 5), (6, 4))
        draw.line((*points, points[0]), fill=ink)
        draw.line((6, 4, 9, 4), fill=ink)
    elif kind == "golden_apple":
        points = ((7, 4), (9, 3), (12, 5), (13, 8), (11, 12), (9, 13),
                  (7, 12), (5, 13), (3, 10), (3, 7), (5, 4))
        draw.line((*points, points[0]), fill=ink)
        draw.line((8, 3, 9, 1, 11, 1), fill=ink)
        draw.line((9, 3, 12, 2), fill=ink)
    else:
        raise ValueError(kind)
    return image


def capturer(color: tuple[int, int, int, int]) -> Image.Image:
    image = Image.new("RGBA", (16, 16))
    draw = ImageDraw.Draw(image)
    ink = (31, 31, 31, 230)
    draw.ellipse((2, 2, 13, 13), outline=ink)
    draw.ellipse((3, 3, 12, 12), outline=color)
    draw.line((3, 7, 12, 7), fill=ink)
    draw.line((7, 3, 7, 12), fill=ink)
    draw.rectangle((6, 6, 8, 8), outline=ink)
    return image


def assets() -> dict[Path, Image.Image]:
    result = {
        BACKGROUNDS / f"{name}.png": machine_background(colors)
        for name, colors in PALETTES.items()
    }
    result.update({
        CAPTURES / "empty_villager_head.png": villager_head(),
        CAPTURES / "empty_piglin_head.png": piglin_head(),
        CAPTURES / "empty_villager_capturer.png": capturer((76, 143, 173, 230)),
        CAPTURES / "empty_piglin_capturer.png": capturer((165, 66, 75, 230)),
        MACHINE_SLOTS / "empty_hoe.png": outline_sprite("hoe"),
        MACHINE_SLOTS / "empty_wheat_seeds.png": outline_sprite("wheat_seeds"),
        MACHINE_SLOTS / "empty_weakness_potion.png": outline_sprite("weakness_potion"),
        MACHINE_SLOTS / "empty_golden_apple.png": outline_sprite("golden_apple"),
    })
    return result


def validate(committed: bool) -> None:
    failures: list[str] = []
    for path, expected in assets().items():
        if not path.exists():
            failures.append(f"missing {path.relative_to(ROOT)}")
            continue
        with Image.open(path) as source:
            actual = source.convert("RGBA")
        if actual.size != expected.size:
            failures.append(f"{path.name}: {actual.size}, expected {expected.size}")
        elif committed and ImageChops.difference(actual, expected).getbbox() is not None:
            failures.append(f"{path.name}: does not match generator")
    if failures:
        raise SystemExit("\n".join(failures))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if args.check:
        validate(True)
        print("Machine GUI textures valid.")
        return
    BACKGROUNDS.mkdir(parents=True, exist_ok=True)
    expected_backgrounds = {f"{name}.png" for name in PALETTES}
    for stale in BACKGROUNDS.glob("*.png"):
        if stale.name not in expected_backgrounds:
            stale.unlink()
    for path, image in assets().items():
        path.parent.mkdir(parents=True, exist_ok=True)
        image.save(path)
    validate(True)
    print("Generated machine GUI backgrounds and empty-slot sprites.")


if __name__ == "__main__":
    main()
