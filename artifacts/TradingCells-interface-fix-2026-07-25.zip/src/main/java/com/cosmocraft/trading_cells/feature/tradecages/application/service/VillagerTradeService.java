package com.cosmocraft.trading_cells.feature.tradecages.application.service;

import com.cosmocraft.trading_cells.feature.tradecages.application.port.input.TradeCageUseCase;
import com.cosmocraft.trading_cells.feature.machines.application.port.output.MachineSettingsPort;
import com.cosmocraft.trading_cells.feature.tradecages.domain.model.PiglinBarterCycle;
import com.cosmocraft.trading_cells.feature.villagertrading.domain.model.VillagerOfferPersistence;
import java.util.Objects;

/** Application boundary shared by villager and piglin trading machines. */
public final class VillagerTradeService implements TradeCageUseCase {
    private final MachineSettingsPort settings;

    public VillagerTradeService(MachineSettingsPort settings) {
        this.settings = Objects.requireNonNull(settings);
    }

    public int offerRefreshTicks() {
        return VillagerOfferPersistence.refreshIntervalTicks(
                settings.villagerTradeRefreshTicks()
        );
    }

    public boolean infiniteTrades() {
        return settings.villagerInfiniteTrades();
    }

    public PiglinBarterCycle.Step advancePiglinBarter(int remainingTicks, boolean canStart) {
        return PiglinBarterCycle.advance(
                remainingTicks,
                settings.piglinBarterTicks(),
                canStart
        );
    }
}
