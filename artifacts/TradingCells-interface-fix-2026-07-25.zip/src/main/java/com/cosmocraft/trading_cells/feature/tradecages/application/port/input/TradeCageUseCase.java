package com.cosmocraft.trading_cells.feature.tradecages.application.port.input;

import com.cosmocraft.trading_cells.feature.tradecages.domain.model.PiglinBarterCycle;

public interface TradeCageUseCase {
    int offerRefreshTicks();

    boolean infiniteTrades();

    PiglinBarterCycle.Step advancePiglinBarter(int remainingTicks, boolean canStart);
}
