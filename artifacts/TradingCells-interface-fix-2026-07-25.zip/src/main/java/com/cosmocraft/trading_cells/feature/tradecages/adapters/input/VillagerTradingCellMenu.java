package com.cosmocraft.trading_cells.feature.tradecages.adapters.input;

import com.cosmocraft.trading_cells.feature.tradecages.adapters.output.TradingCellsRegistrationAdapter;
import com.cosmocraft.trading_cells.platform.neoforge.menu.VillagerTradeEquipmentSlots;
import com.cosmocraft.trading_cells.platform.neoforge.menu.VillagerTradeMenuLayout;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.npc.ClientSideMerchant;
import net.minecraft.world.entity.npc.villager.VillagerData;
import net.minecraft.world.entity.npc.villager.VillagerProfession;
import net.minecraft.world.entity.npc.villager.VillagerType;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MerchantContainer;
import net.minecraft.world.inventory.MerchantResultSlot;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.Merchant;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import java.util.ArrayList;
import java.util.List;
import org.jspecify.annotations.NonNull;

/** Custom manual-trading menu used only by the Villager Trading Cell. */
public final class VillagerTradingCellMenu extends AbstractContainerMenu {
    public static final int SELECT_OFFER_BUTTON_BASE = 100;

    private static final int PAYMENT_A_SLOT = 0;
    private static final int PAYMENT_B_SLOT = 1;
    private static final int RESULT_SLOT = 2;
    private static final int PLAYER_INVENTORY_START = 3;
    private static final int PLAYER_INVENTORY_END = PLAYER_INVENTORY_START + 27;
    private static final int PLAYER_HOTBAR_END = PLAYER_INVENTORY_END + 9;
    private static final int EQUIPMENT_START = PLAYER_HOTBAR_END;
    private static final int EQUIPMENT_END = EQUIPMENT_START + 5;

    private final Merchant trader;
    private final MerchantContainer tradeContainer;
    private int merchantLevel;
    private int merchantXp;
    private int storedExperience;
    private int offersRevision;
    private boolean showProgressBar;
    private boolean canRestock;
    private boolean canResetTrades;
    private boolean hasServerSnapshot;
    private VillagerData villagerData;
    private int selectedOfferIndex;

    public VillagerTradingCellMenu(int containerId, Inventory inventory) {
        this(containerId, inventory, new ClientSideMerchant(inventory.player));
    }

    public VillagerTradingCellMenu(int containerId, Inventory inventory, Merchant merchant) {
        super(TradingCellsRegistrationAdapter.VILLAGER_TRADING_CELL_MENU.get(), containerId);
        this.trader = merchant;
        this.tradeContainer = new MerchantContainer(merchant);
        this.villagerData = new VillagerData(
                BuiltInRegistries.VILLAGER_TYPE.getOrThrow(VillagerType.PLAINS),
                BuiltInRegistries.VILLAGER_PROFESSION.getOrThrow(VillagerProfession.NONE),
                1
        );

        addSlot(new Slot(
                tradeContainer,
                PAYMENT_A_SLOT,
                VillagerTradeMenuLayout.itemX(VillagerTradeMenuLayout.MANUAL_PAYMENT_A_X),
                VillagerTradeMenuLayout.itemY(VillagerTradeMenuLayout.MANUAL_TRADER_SLOT_Y)
        ));
        addSlot(new Slot(
                tradeContainer,
                PAYMENT_B_SLOT,
                VillagerTradeMenuLayout.itemX(VillagerTradeMenuLayout.MANUAL_PAYMENT_B_X),
                VillagerTradeMenuLayout.itemY(VillagerTradeMenuLayout.MANUAL_TRADER_SLOT_Y)
        ));
        addSlot(new MerchantResultSlot(
                inventory.player,
                merchant,
                tradeContainer,
                RESULT_SLOT,
                VillagerTradeMenuLayout.itemX(VillagerTradeMenuLayout.MANUAL_RESULT_X),
                VillagerTradeMenuLayout.itemY(VillagerTradeMenuLayout.MANUAL_TRADER_SLOT_Y)
        ));
        addStandardInventorySlots(
                inventory,
                VillagerTradeMenuLayout.itemX(VillagerTradeMenuLayout.PLAYER_INVENTORY_X),
                VillagerTradeMenuLayout.itemY(VillagerTradeMenuLayout.PLAYER_INVENTORY_Y)
        );
        for (Slot equipmentSlot : VillagerTradeEquipmentSlots.create(inventory)) {
            addSlot(equipmentSlot);
        }
    }

    public MerchantOffers getOffers() {
        return trader.getOffers();
    }

    public void setOffers(MerchantOffers offers) {
        trader.overrideOffers(offers);
        selectedOfferIndex = offers.isEmpty() ? 0 : Math.min(selectedOfferIndex, offers.size() - 1);
        setSelectionHint(selectedOfferIndex);
    }

    public int selectedOfferIndex() {
        return selectedOfferIndex;
    }

    public MerchantOffer selectedOffer() {
        MerchantOffers offers = getOffers();
        return offers.isEmpty() ? null : offers.get(Math.floorMod(selectedOfferIndex, offers.size()));
    }

    public void setSelectionHint(int index) {
        selectedOfferIndex = Math.max(0, index);
        tradeContainer.setSelectionHint(selectedOfferIndex);
    }

    public int merchantLevel() {
        return merchantLevel;
    }

    public int merchantXp() {
        return merchantXp;
    }

    public boolean showProgressBar() {
        return showProgressBar;
    }

    public boolean canRestock() {
        return canRestock;
    }

    public int storedExperience() {
        return storedExperience;
    }

    public void setStoredExperience(int experience) {
        storedExperience = Math.max(0, experience);
    }

    public boolean canResetTrades() {
        return canResetTrades;
    }

    public VillagerData villagerData() {
        return villagerData;
    }

    public int offersRevision() {
        return offersRevision;
    }

    public void applyServerState(
            MerchantOffers offers,
            VillagerData data,
            int level,
            int xp,
            int storedXp,
            int selectedIndex,
            boolean showProgress,
            boolean restock,
            boolean reset,
            int revision
    ) {
        if (hasServerSnapshot && revision < offersRevision) {
            return;
        }
        setOffers(offers);
        villagerData = data;
        merchantLevel = level;
        merchantXp = xp;
        storedExperience = Math.max(0, storedXp);
        setSelectionHint(offers.isEmpty() ? 0 : Math.min(Math.max(0, selectedIndex), offers.size() - 1));
        showProgressBar = showProgress;
        canRestock = restock;
        canResetTrades = reset;
        offersRevision = Math.max(0, revision);
        hasServerSnapshot = true;
    }

    @Override
    public void slotsChanged(Container container) {
        tradeContainer.updateSellItem();
        super.slotsChanged(container);
    }

    public boolean selectOfferFromPacket(Player player, int offerIndex, int knownRevision) {
        if (knownRevision != offersRevision
                || offerIndex < 0
                || offerIndex >= getOffers().size()
                || !stillValid(player)) {
            return false;
        }
        return tryChangeOffer(player, offerIndex);
    }

    @Override
    public boolean clickMenuButton(@NonNull Player player, int buttonId) {
        int offerIndex = buttonId - SELECT_OFFER_BUTTON_BASE;
        if (offerIndex < 0 || offerIndex >= getOffers().size()) {
            return false;
        }
        return selectOfferFromPacket(player, offerIndex, offersRevision);
    }

    @Override
    public boolean stillValid(@NonNull Player player) {
        return trader.stillValid(player);
    }

    @Override
    public boolean canTakeItemForPickAll(ItemStack carried, Slot target) {
        return false;
    }

    @Override
    public @NonNull ItemStack quickMoveStack(@NonNull Player player, int slotIndex) {
        ItemStack clicked = ItemStack.EMPTY;
        Slot slot = slots.get(slotIndex);
        if (slot == null || !slot.hasItem()) {
            return ItemStack.EMPTY;
        }

        ItemStack stack = slot.getItem();
        clicked = stack.copy();
        if (slotIndex == RESULT_SLOT) {
            if (!moveItemStackTo(stack, PLAYER_INVENTORY_START, PLAYER_HOTBAR_END, true)) {
                return ItemStack.EMPTY;
            }
            slot.onQuickCraft(stack, clicked);
            playTradeSound();
        } else if (slotIndex == PAYMENT_A_SLOT || slotIndex == PAYMENT_B_SLOT) {
            if (!moveItemStackTo(stack, PLAYER_INVENTORY_START, PLAYER_HOTBAR_END, false)) {
                return ItemStack.EMPTY;
            }
        } else if (slotIndex >= EQUIPMENT_START && slotIndex < EQUIPMENT_END) {
            if (!moveItemStackTo(stack, PLAYER_INVENTORY_START, PLAYER_HOTBAR_END, false)) {
                return ItemStack.EMPTY;
            }
        } else if (slotIndex >= PLAYER_INVENTORY_START && slotIndex < PLAYER_HOTBAR_END) {
            MerchantOffer offer = selectedOffer();
            boolean movedToCost = false;
            int preferredPayment = preferredPaymentSlot(offer, stack);
            if (preferredPayment >= PAYMENT_A_SLOT && preferredPayment <= PAYMENT_B_SLOT) {
                movedToCost = moveItemStackTo(stack, preferredPayment, preferredPayment + 1, false);
            }
            if (!movedToCost && !tryMoveToEquipment(player, stack)) {
                if (slotIndex < PLAYER_INVENTORY_END) {
                    if (!moveItemStackTo(stack, PLAYER_INVENTORY_END, PLAYER_HOTBAR_END, false)) {
                        return ItemStack.EMPTY;
                    }
                } else if (!moveItemStackTo(stack, PLAYER_INVENTORY_START, PLAYER_INVENTORY_END, false)) {
                    return ItemStack.EMPTY;
                }
            }
        }

        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        if (stack.getCount() == clicked.getCount()) {
            return ItemStack.EMPTY;
        }
        slot.onTake(player, stack);
        return clicked;
    }

    @Override
    public void removed(@NonNull Player player) {
        super.removed(player);
        trader.setTradingPlayer(null);
        if (!trader.isClientSide()) {
            returnPaymentItems(player);
        }
    }


    private int preferredPaymentSlot(MerchantOffer offer, ItemStack stack) {
        if (offer == null) {
            return -1;
        }
        boolean matchesA = offer.getItemCostA().test(stack);
        boolean matchesB = offer.getItemCostB().map(cost -> cost.test(stack)).orElse(false);
        if (!matchesA && !matchesB) {
            return -1;
        }
        if (matchesA && !matchesB) {
            return PAYMENT_A_SLOT;
        }
        if (!matchesA) {
            return PAYMENT_B_SLOT;
        }
        int currentA = tradeContainer.getItem(PAYMENT_A_SLOT).getCount();
        if (currentA < offer.getCostA().getCount()) {
            return PAYMENT_A_SLOT;
        }
        int currentB = tradeContainer.getItem(PAYMENT_B_SLOT).getCount();
        return currentB < offer.getCostB().getCount() ? PAYMENT_B_SLOT : PAYMENT_A_SLOT;
    }

    private boolean tryMoveToEquipment(Player player, ItemStack stack) {
        EquipmentSlot equipmentSlot = player.getEquipmentSlotForItem(stack);
        int target = switch (equipmentSlot) {
            case OFFHAND -> EQUIPMENT_START;
            case HEAD -> EQUIPMENT_START + 1;
            case CHEST -> EQUIPMENT_START + 2;
            case LEGS -> EQUIPMENT_START + 3;
            case FEET -> EQUIPMENT_START + 4;
            default -> -1;
        };
        return target >= EQUIPMENT_START
                && target < EQUIPMENT_END
                && !slots.get(target).hasItem()
                && slots.get(target).mayPlace(stack)
                && moveItemStackTo(stack, target, target + 1, false);
    }

    /**
     * Changes the selected offer without ever destroying or trapping payment items.
     * Both current payment stacks are first simulated back into the 36 player
     * inventory slots. The selection changes only if that complete return fits.
     */
    private boolean tryChangeOffer(Player player, int newTradeIndex) {
        if (newTradeIndex < 0 || newTradeIndex >= getOffers().size()) {
            return false;
        }

        PaymentReturnPlan returnPlan = simulatePaymentReturn(player);
        if (returnPlan == null) {
            return false;
        }

        commitPaymentReturn(player, returnPlan);
        setSelectionHint(newTradeIndex);

        MerchantOffer offer = getOffers().get(newTradeIndex);
        moveFromInventoryToPaymentSlot(PAYMENT_A_SLOT, offer.getItemCostA());
        offer.getItemCostB().ifPresent(cost -> moveFromInventoryToPaymentSlot(PAYMENT_B_SLOT, cost));
        tradeContainer.updateSellItem();
        broadcastChanges();
        return true;
    }

    PaymentReturnPlan simulatePaymentReturn(Player player) {
        ItemStack oldA = tradeContainer.getItem(PAYMENT_A_SLOT).copy();
        ItemStack oldB = tradeContainer.getItem(PAYMENT_B_SLOT).copy();
        List<ItemStack> simulated = simulatePlayerInventory(player, oldA, oldB);
        return simulated == null ? null : new PaymentReturnPlan(simulated);
    }

    void commitPaymentReturn(Player player, PaymentReturnPlan plan) {
        commitPlayerInventory(player, plan.inventory());
        tradeContainer.setItem(PAYMENT_A_SLOT, ItemStack.EMPTY);
        tradeContainer.setItem(PAYMENT_B_SLOT, ItemStack.EMPTY);
        tradeContainer.updateSellItem();
        broadcastChanges();
    }

    private static List<ItemStack> simulatePlayerInventory(Player player, ItemStack... returnedStacks) {
        List<ItemStack> simulated = new ArrayList<>(36);
        for (int index = 0; index < 36; index++) {
            simulated.add(player.getInventory().getItem(index).copy());
        }
        for (ItemStack source : returnedStacks) {
            ItemStack remaining = source.copy();
            if (remaining.isEmpty()) {
                continue;
            }
            for (ItemStack target : simulated) {
                if (remaining.isEmpty()) {
                    break;
                }
                if (!target.isEmpty() && ItemStack.isSameItemSameComponents(target, remaining)) {
                    int move = Math.min(remaining.getCount(), target.getMaxStackSize() - target.getCount());
                    if (move > 0) {
                        target.grow(move);
                        remaining.shrink(move);
                    }
                }
            }
            for (int index = 0; index < simulated.size() && !remaining.isEmpty(); index++) {
                if (simulated.get(index).isEmpty()) {
                    int move = Math.min(remaining.getCount(), remaining.getMaxStackSize());
                    simulated.set(index, remaining.copyWithCount(move));
                    remaining.shrink(move);
                }
            }
            if (!remaining.isEmpty()) {
                return null;
            }
        }
        return simulated;
    }

    private static void commitPlayerInventory(Player player, List<ItemStack> simulated) {
        for (int index = 0; index < 36; index++) {
            player.getInventory().setItem(index, simulated.get(index));
        }
        player.getInventory().setChanged();
    }

    private void moveFromInventoryToPaymentSlot(int paymentSlot, ItemCost cost) {
        for (int i = PLAYER_INVENTORY_START; i < PLAYER_HOTBAR_END; i++) {
            ItemStack inventoryItem = slots.get(i).getItem();
            if (inventoryItem.isEmpty() || !cost.test(inventoryItem)) {
                continue;
            }
            ItemStack payment = tradeContainer.getItem(paymentSlot);
            if (!payment.isEmpty() && !ItemStack.isSameItemSameComponents(inventoryItem, payment)) {
                continue;
            }
            int moveCount = Math.min(inventoryItem.getCount(), inventoryItem.getMaxStackSize() - payment.getCount());
            ItemStack newPayment = inventoryItem.copyWithCount(payment.getCount() + moveCount);
            inventoryItem.shrink(moveCount);
            tradeContainer.setItem(paymentSlot, newPayment);
            if (newPayment.getCount() >= newPayment.getMaxStackSize()) {
                break;
            }
        }
    }

    private void returnPaymentItems(Player player) {
        ItemStack first = tradeContainer.removeItemNoUpdate(PAYMENT_A_SLOT);
        ItemStack second = tradeContainer.removeItemNoUpdate(PAYMENT_B_SLOT);
        if (!player.isAlive() || player instanceof ServerPlayer serverPlayer && serverPlayer.hasDisconnected()) {
            if (!first.isEmpty()) {
                player.drop(first, false);
            }
            if (!second.isEmpty()) {
                player.drop(second, false);
            }
            return;
        }
        if (!first.isEmpty()) {
            player.getInventory().placeItemBackInInventory(first);
        }
        if (!second.isEmpty()) {
            player.getInventory().placeItemBackInInventory(second);
        }
    }

    record PaymentReturnPlan(List<ItemStack> inventory) {
        PaymentReturnPlan {
            inventory = List.copyOf(inventory);
        }
    }

    private void playTradeSound() {
        if (!trader.isClientSide() && trader instanceof Entity entity) {
            entity.level().playLocalSound(
                    entity.getX(),
                    entity.getY(),
                    entity.getZ(),
                    trader.getNotifyTradeSound(),
                    SoundSource.NEUTRAL,
                    1.0F,
                    1.0F,
                    false
            );
        }
    }
}
