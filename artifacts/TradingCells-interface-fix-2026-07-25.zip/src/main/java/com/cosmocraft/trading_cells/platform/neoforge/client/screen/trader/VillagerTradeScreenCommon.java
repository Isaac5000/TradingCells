package com.cosmocraft.trading_cells.platform.neoforge.client.screen.trader;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.npc.villager.VillagerData;
import net.minecraft.world.entity.npc.villager.VillagerProfession;
import org.jspecify.annotations.Nullable;

/** Shared visual rules for the manual and automatic villager trade screens. */
public final class VillagerTradeScreenCommon {
    public static final int TEXT_DARK = 0xFF3A3A3A;
    private static final Identifier EXPERIENCE_ORB_TEXTURE =
            Identifier.withDefaultNamespace("textures/entity/experience/experience_orb.png");
    private static final Identifier EXPERIENCE_BAR_BACKGROUND =
            Identifier.withDefaultNamespace("container/villager/experience_bar_background");
    private static final Identifier EXPERIENCE_BAR_CURRENT =
            Identifier.withDefaultNamespace("container/villager/experience_bar_current");

    private VillagerTradeScreenCommon() {
    }

    public static Component professionDisplayName(@Nullable VillagerData data) {
        if (data == null || data.profession() == VillagerProfession.NONE) {
            return Component.translatable("tooltip.trading_cells.unemployed");
        }
        if (data.profession() == VillagerProfession.NITWIT) {
            return Component.translatable("entity.minecraft.villager.nitwit");
        }
        return data.profession().unwrapKey()
                .map(key -> {
                    Identifier id = key.identifier();
                    return Component.translatable(
                            "entity." + id.getNamespace() + ".villager." + id.getPath()
                    );
                })
                .orElse(Component.translatable("gui.trading_cells.profession_title"));
    }

    public static Component levelName(int level) {
        return Component.translatable("merchant.level." + Math.max(1, level));
    }

    public static Component professionExperienceText(int level, int experience) {
        ProfessionProgress progress = professionProgress(level, experience);
        return progress.maximum()
                ? Component.translatable("gui.trading_cells.maximum")
                : Component.translatable(
                        "gui.trading_cells.profession_xp",
                        Math.max(0, experience),
                        progress.maximumExperience()
                );
    }

    public static ProfessionProgress professionProgress(int level, int experience) {
        int safeLevel = Math.max(1, level);
        int minimum = VillagerData.getMinXpPerLevel(safeLevel);
        int maximum = VillagerData.getMaxXpPerLevel(safeLevel);
        boolean atMaximum = !VillagerData.canLevelUp(safeLevel) || maximum <= minimum;
        float fraction = atMaximum
                ? 1.0F
                : Mth.clamp((experience - minimum) / (float) (maximum - minimum), 0.0F, 1.0F);
        return new ProfessionProgress(minimum, maximum, fraction, atMaximum);
    }

    public static void drawProfessionProgress(
            GuiGraphicsExtractor graphics,
            int x,
            int y,
            int width,
            int level,
            int experience
    ) {
        float progress = professionProgress(level, experience).fraction();
        int filled = Math.round(width * progress);
        graphics.blitSprite(
                RenderPipelines.GUI_TEXTURED,
                EXPERIENCE_BAR_BACKGROUND,
                x,
                y + 1,
                width,
                5
        );
        if (filled > 0) {
            graphics.blitSprite(
                    RenderPipelines.GUI_TEXTURED,
                    EXPERIENCE_BAR_CURRENT,
                    width,
                    5,
                    0,
                    0,
                    x,
                    y + 1,
                    Math.min(width, filled),
                    5
            );
        }
    }

    public static void drawStoredExperiencePanel(
            GuiGraphicsExtractor graphics,
            int x,
            int y,
            int width,
            int height,
            int orbX,
            int orbY
    ) {
        graphics.fill(x, y, x + width, y + height, 0xFF343A31);
        graphics.fill(x + 1, y + 1, x + width - 1, y + height - 1, 0xFFA8B0A0);
        graphics.fill(x + 1, y + 1, x + width - 1, y + 2, 0xFF6C7468);
        graphics.fill(x + 1, y + 1, x + 2, y + height - 1, 0xFF6C7468);
        graphics.fill(x + 1, y + height - 2, x + width - 1, y + height - 1, 0xFFD2D7CC);
        graphics.fill(x + width - 2, y + 1, x + width - 1, y + height - 1, 0xFFD2D7CC);
        graphics.blit(
                RenderPipelines.GUI_TEXTURED,
                EXPERIENCE_ORB_TEXTURE,
                orbX,
                orbY,
                32.0F,
                0.0F,
                16,
                16,
                16,
                16,
                64,
                64,
                0xFF9CFF45
        );
    }

    public static void drawTradeArrow(
            GuiGraphicsExtractor graphics,
            Identifier enabledTexture,
            Identifier disabledTexture,
            int x,
            int y,
            boolean disabled
    ) {
        Identifier texture = disabled ? disabledTexture : enabledTexture;
        graphics.blit(RenderPipelines.GUI_TEXTURED, texture, x, y, 0, 0, 14, 10, 14, 10);
    }

    public static void drawDropdownChevron(
            GuiGraphicsExtractor graphics,
            int x,
            int y,
            boolean enabled,
            boolean hovered
    ) {
        int shadow = enabled ? (hovered ? 0xFF3F3F3F : 0xFF575757) : 0xFF8B8B8B;
        int light = enabled ? (hovered ? 0xFF686868 : 0xFF767676) : 0xFFAAAAAA;
        graphics.fill(x, y, x + 5, y + 1, light);
        graphics.fill(x + 1, y + 1, x + 4, y + 2, shadow);
        graphics.fill(x + 2, y + 2, x + 3, y + 3, shadow);
    }

    public static void drawBeveledButton(
            GuiGraphicsExtractor graphics,
            int x,
            int y,
            int width,
            int height,
            boolean active,
            boolean hovered,
            boolean pressed
    ) {
        int outer = active ? 0xFF404040 : 0xFF5D5D5D;
        int fill = !active ? 0xFF929292 : pressed ? 0xFFB8B8B8 : hovered ? 0xFFE2E2E2 : 0xFFD0D0D0;
        int light = !active ? 0xFFA8A8A8 : pressed ? 0xFF888888 : 0xFFF0F0F0;
        int shadow = !active ? 0xFF747474 : pressed ? 0xFFE2E2E2 : 0xFF888888;
        graphics.fill(x, y, x + width, y + height, outer);
        graphics.fill(x + 1, y + 1, x + width - 1, y + height - 1, fill);
        graphics.fill(x + 1, y + 1, x + width - 1, y + 2, light);
        graphics.fill(x + 1, y + 1, x + 2, y + height - 1, light);
        graphics.fill(x + 1, y + height - 2, x + width - 1, y + height - 1, shadow);
        graphics.fill(x + width - 2, y + 1, x + width - 1, y + height - 1, shadow);
    }

    public static int buttonTextColor(boolean active) {
        return active ? TEXT_DARK : 0xFFE0E0E0;
    }

    public static void drawCenteredText(
            GuiGraphicsExtractor graphics,
            Font font,
            Component text,
            int centerX,
            int y,
            int color
    ) {
        graphics.text(font, text, centerX - font.width(text) / 2, y, color, false);
    }

    public record ProfessionProgress(
            int minimumExperience,
            int maximumExperience,
            float fraction,
            boolean maximum
    ) {
    }
}
