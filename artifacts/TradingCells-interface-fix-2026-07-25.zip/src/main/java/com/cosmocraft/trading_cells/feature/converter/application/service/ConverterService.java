package com.cosmocraft.trading_cells.feature.converter.application.service;

import com.cosmocraft.trading_cells.feature.converter.application.port.input.ConverterUseCase;
import com.cosmocraft.trading_cells.feature.converter.domain.model.ConverterCycle;
import com.cosmocraft.trading_cells.feature.converter.domain.model.ConverterStage;
import com.cosmocraft.trading_cells.feature.machines.application.port.output.MachineSettingsPort;
import java.util.Objects;

/** Application boundary for converter state and configurable cure strength. */
public final class ConverterService implements ConverterUseCase {
    private final MachineSettingsPort settings;

    public ConverterService(MachineSettingsPort settings) {
        this.settings = Objects.requireNonNull(settings);
    }

    public int durationTicks(ConverterStage stage) {
        return stage.durationTicks(
                settings.converterInfectionTicks(),
                settings.converterCureTicks()
        );
    }

    public ConverterCycle.Step advance(
            ConverterStage stage,
            int ticks,
            boolean hasValidVillager,
            boolean canStart,
            boolean curedReady
    ) {
        return ConverterCycle.advance(
                stage,
                ticks,
                hasValidVillager,
                canStart,
                curedReady,
                settings.converterInfectionTicks(),
                settings.converterCureTicks()
        );
    }

    public int increasedCureDiscount(int current) {
        long increased = (long) Math.max(0, current)
                + Math.max(0, settings.converterCureDiscountPerCycle());
        return (int) Math.min(
                Math.max(0, settings.converterMaximumCureDiscount()),
                Math.min(Integer.MAX_VALUE, increased)
        );
    }
}
