package com.cosmocraft.trading_cells.feature.tradecages.adapters.input;

import com.cosmocraft.trading_cells.feature.captures.adapters.api.CapturedMobStackAdapter;
import com.cosmocraft.trading_cells.feature.captures.domain.model.CapturedMobKind;
import com.cosmocraft.trading_cells.platform.neoforge.bootstrap.FeatureComposition;
import com.cosmocraft.trading_cells.feature.tradecages.adapters.output.TradingCellsRegistrationAdapter;
import com.cosmocraft.trading_cells.feature.tradecages.application.port.input.TradeCageUseCase;
import com.cosmocraft.trading_cells.feature.villagertrading.domain.service.TradeDiscountPolicy;
import com.cosmocraft.trading_cells.platform.neoforge.network.TradingCellExperiencePayload;
import com.cosmocraft.trading_cells.platform.neoforge.network.TradingCellMenuSyncPayload;
import com.cosmocraft.trading_cells.platform.neoforge.trading.MerchantOfferComparator;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.util.Mth;
import net.minecraft.util.ProblemReporter;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.village.ReputationEventType;
import net.minecraft.world.entity.ai.village.poi.PoiType;
import net.minecraft.world.entity.ai.village.poi.PoiTypes;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.entity.npc.villager.VillagerData;
import net.minecraft.world.entity.npc.villager.VillagerProfession;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.TagValueInput;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

public class VillagerTradingCellBlockEntity extends BlockEntity {
    private static final String CURE_DISCOUNT_TAG = "TradingCellsCureDiscount";
    private static final String TEMPORARY_DISCOUNT_MASK_TAG = "TradingCellsTemporaryDiscountMask";
    private static final String TEMPORARY_DISCOUNT_EXPIRES_TAG = "TradingCellsTemporaryDiscountExpires";
    private static final String LEGACY_VILLAGER_DATA_TAG = "StoredVillager";
    private static final String ENTITY_KIND_TAG = "StoredEntityKind";
    private static final String ENTITY_DATA_TAG = "StoredEntity";
    private static final String POI_STACK_TAG = "StoredPoi";
    private static final String TRADE_REFRESH_TICKS_TAG = "TradeRefreshTicks";
    private static final String STORED_EXPERIENCE_TAG = "StoredExperience";
    private static final int RESTOCK_CHECK_INTERVAL_TICKS = 300;

    private static final String VILLAGER_DATA_TAG = "VillagerData";
    private static final String PROFESSION_TAG = "profession";
    private static final String LEVEL_TAG = "level";
    private static final String XP_TAG = "Xp";
    private static final String AGE_TAG = "Age";
    private static final String NONE_PROFESSION = "minecraft:none";

    private static final Map<UUID, GlobalPos> OPEN_TRADING_CELLS_BY_PLAYER = new HashMap<>();

    private final TradeCageUseCase villagerTradeService = FeatureComposition.tradeCage();
    private @Nullable StoredEntityKind storedEntityKind;
    private @Nullable CompoundTag storedEntityData;
    private ItemStack storedPoiStack = ItemStack.EMPTY;
    private @Nullable TradingCellVillager merchantVillager;
    private int tradeRefreshTicks;
    private int storedExperience;
    private int offersRevision;

    public static void serverTick(
            Level level,
            BlockPos pos,
            BlockState state,
            VillagerTradingCellBlockEntity cell
    ) {
        cell.tickTradeRefresh();
        cell.tickOpenTradingPriceSync();
    }

    public static void handleResetTradesRequest(Player player, int containerId, int knownOffersRevision) {
        if (!(player.containerMenu instanceof VillagerTradingCellMenu menu)
                || menu.containerId != containerId
                || menu.offersRevision() != knownOffersRevision) {
            return;
        }
        VillagerTradingCellBlockEntity cell = findOpenCell(player);
        if (cell != null && cell.isPlayerStillValid(player)) {
            cell.resetTransientTrades(player);
        }
    }

    public static void handleSelectOfferRequest(
            Player player,
            int containerId,
            int selectedOfferIndex,
            int knownOffersRevision
    ) {
        if (!(player.containerMenu instanceof VillagerTradingCellMenu menu)
                || menu.containerId != containerId
                || menu.offersRevision() != knownOffersRevision) {
            return;
        }
        VillagerTradingCellBlockEntity cell = findOpenCell(player);
        if (cell == null || !cell.isPlayerStillValid(player)) {
            return;
        }
        if (menu.selectOfferFromPacket(player, selectedOfferIndex, knownOffersRevision)) {
            TradingCellVillager villager = cell.getOrCreateMerchantVillager();
            if (villager != null) {
                cell.sendMenuSync(player, villager);
            }
        }
    }

    public static void handleExtractExperienceRequest(Player player, int containerId, byte mode) {
        if (!(player.containerMenu instanceof VillagerTradingCellMenu menu) || menu.containerId != containerId) {
            return;
        }
        VillagerTradingCellBlockEntity cell = findOpenCell(player);
        if (cell != null && cell.isPlayerStillValid(player)) {
            cell.extractStoredExperience(player, mode);
        }
    }

    private static @Nullable VillagerTradingCellBlockEntity findOpenCell(Player player) {
        GlobalPos globalPos = OPEN_TRADING_CELLS_BY_PLAYER.get(player.getUUID());
        if (globalPos == null || player.level().getServer() == null) {
            return null;
        }
        Level level = player.level().getServer().getLevel(globalPos.dimension());
        if (level == null) {
            return null;
        }
        BlockEntity blockEntity = level.getBlockEntity(globalPos.pos());
        if (blockEntity instanceof VillagerTradingCellBlockEntity cell) {
            return cell;
        }
        OPEN_TRADING_CELLS_BY_PLAYER.remove(player.getUUID());
        return null;
    }

    public VillagerTradingCellBlockEntity(BlockPos pos, BlockState blockState) {
        super(TradingCellsRegistrationAdapter.VILLAGER_TRADING_CELL_BLOCK_ENTITY.get(), pos, blockState);
    }

    public boolean hasStoredEntity() {
        return storedEntityKind != null && storedEntityData != null && !storedEntityData.isEmpty();
    }

    public boolean hasVillager() {
        return hasStoredEntity() && storedEntityKind == StoredEntityKind.VILLAGER;
    }

    public boolean hasPiglin() {
        return hasStoredEntity() && storedEntityKind == StoredEntityKind.PIGLIN;
    }

    public boolean hasStoredPoi() {
        return !storedPoiStack.isEmpty();
    }

    public ItemStack copyPoiStack() {
        return storedPoiStack.copy();
    }

    public @Nullable CompoundTag copyVillagerData() {
        return hasVillager() && storedEntityData != null ? storedEntityData.copy() : null;
    }

    public @Nullable CompoundTag copyPiglinData() {
        return hasPiglin() && storedEntityData != null ? storedEntityData.copy() : null;
    }

    public @Nullable CompoundTag copyStoredEntityData() {
        return hasStoredEntity() && storedEntityData != null ? storedEntityData.copy() : null;
    }

    public @Nullable String getStoredEntityKindId() {
        return storedEntityKind == null ? null : storedEntityKind.id;
    }

    public @Nullable Entity createStoredEntityForDisplay() {
        if (level == null || !hasStoredEntity() || storedEntityData == null || storedEntityKind == null) {
            return null;
        }

        return CapturedMobStackAdapter.createEntity(
                capturedKind(storedEntityKind),
                level,
                storedEntityData,
                worldPosition
        );
    }

    public InteractionResult insertVillagerFromCapturer(ItemStack stack, Player player) {
        if (hasStoredEntity()) {
            return InteractionResult.SUCCESS_SERVER;
        }

        CompoundTag villagerData = CapturedMobStackAdapter.copyData(CapturedMobKind.VILLAGER, stack);
        if (villagerData == null) {
            return InteractionResult.PASS;
        }

        setStoredEntity(StoredEntityKind.VILLAGER, villagerData);
        refreshVillagerProfessionFromPoi();
        CapturedMobStackAdapter.clearData(CapturedMobKind.VILLAGER, stack);
        return InteractionResult.SUCCESS_SERVER;
    }

    public InteractionResult extractVillagerToCapturer(ItemStack stack, Player player) {
        if (!hasStoredEntity()) {
            return InteractionResult.SUCCESS_SERVER;
        }

        if (!hasVillager()) {
            return InteractionResult.SUCCESS_SERVER;
        }

        if (CapturedMobStackAdapter.isFilledCapturer(CapturedMobKind.VILLAGER, stack)) {
            return InteractionResult.SUCCESS_SERVER;
        }

        saveProxyToStoredData();
        CompoundTag villagerData = copyVillagerData();
        if (villagerData == null) {
            return InteractionResult.FAIL;
        }

        ItemStack targetStack = createSingleCapturerTarget(stack);
        CapturedMobStackAdapter.setData(CapturedMobKind.VILLAGER, targetStack, villagerData);
        finishStackedExtraction(player, stack, targetStack);
        clearStoredEntity();
        return InteractionResult.SUCCESS_SERVER;
    }

    public InteractionResult extractPiglinToCapturer(ItemStack stack, Player player) {
        if (!hasStoredEntity()) {
            return InteractionResult.SUCCESS_SERVER;
        }

        if (!hasPiglin()) {
            return InteractionResult.SUCCESS_SERVER;
        }

        if (CapturedMobStackAdapter.isFilledCapturer(CapturedMobKind.PIGLIN, stack)) {
            return InteractionResult.SUCCESS_SERVER;
        }

        CompoundTag piglinData = copyPiglinData();
        if (piglinData == null) {
            return InteractionResult.FAIL;
        }

        ItemStack targetStack = createSingleCapturerTarget(stack);
        CapturedMobStackAdapter.setData(CapturedMobKind.PIGLIN, targetStack, piglinData);
        finishStackedExtraction(player, stack, targetStack);
        clearStoredEntity();
        return InteractionResult.SUCCESS_SERVER;
    }

    public InteractionResult insertPoiFromStack(ItemStack stack, Player player) {
        String professionId = getProfessionForPoiStack(stack);
        if (professionId == null) {
            return InteractionResult.PASS;
        }

        boolean replacingPoi = hasStoredPoi();
        if (replacingPoi) {
            saveProxyToStoredData();
            if (hasPersistentVillagerProfession()) {
                return InteractionResult.SUCCESS_SERVER;
            }

            ItemStack previousPoi = storedPoiStack.copy();
            if (!player.getInventory().add(previousPoi)) {
                return InteractionResult.SUCCESS_SERVER;
            }
        }

        storedPoiStack = stack.copyWithCount(1);
        stack.shrink(1);
        refreshVillagerProfessionFromPoi();
        markChangedAndSync();
        return InteractionResult.SUCCESS_SERVER;
    }

    public InteractionResult extractPoiToPlayer(Player player) {
        if (!hasStoredPoi()) {
            return InteractionResult.SUCCESS_SERVER;
        }

        ItemStack poiToReturn = storedPoiStack.copy();
        if (!player.getInventory().add(poiToReturn)) {
            return InteractionResult.SUCCESS_SERVER;
        }

        storedPoiStack = ItemStack.EMPTY;
        clearTransientVillagerProfession();
        markChangedAndSync();
        return InteractionResult.SUCCESS_SERVER;
    }

    public InteractionResult releaseStoredEntityIntoWorld(Player player, BlockPos releasePos) {
        if (!hasStoredEntity()) {
            return InteractionResult.SUCCESS_SERVER;
        }

        if (level == null || level.isClientSide() || storedEntityKind == null || storedEntityData == null) {
            return InteractionResult.SUCCESS;
        }

        saveProxyToStoredData();
        Entity entity = createEntity(level, storedEntityKind, storedEntityData, releasePos);
        if (entity == null || !level.addFreshEntity(entity)) {
            return InteractionResult.FAIL;
        }

        clearStoredEntity();
        return InteractionResult.SUCCESS_SERVER;
    }

    public boolean resetTransientTrades(Player player) {
        if (!hasVillager()) {
            return false;
        }

        saveProxyToStoredData();
        if (storedEntityData == null) {
            return false;
        }
        if (isVillagerBaby(storedEntityData)) {
            return false;
        }
        if (isVillagerProfessionPersistent(storedEntityData)) {
            return false;
        }

        String professionId = getProfessionForPoiStack(storedPoiStack);
        if (professionId == null) {
            return false;
        }

        TradingCellVillager villager = getOrCreateMerchantVillager();
        if (villager == null || villager.getVillagerXp() != 0) {
            return false;
        }

        VillagerTradingCellMenu openMenu = player.containerMenu instanceof VillagerTradingCellMenu menu ? menu : null;
        VillagerTradingCellMenu.PaymentReturnPlan paymentReturnPlan = openMenu == null
                ? null
                : openMenu.simulatePaymentReturn(player);
        if (openMenu != null && paymentReturnPlan == null) {
            return false;
        }

        CompoundTag previousStoredEntityData = storedEntityData.copy();
        MerchantOffer previouslySelected = openMenu == null ? null : openMenu.selectedOffer();

        clearVillagerProfession(storedEntityData);
        setVillagerProfession(storedEntityData, professionId);
        reloadMerchantVillagerFromStoredData(villager);
        villager.setTradingPlayer(player);

        MerchantOffers offers = villager.getOffers();
        if (offers.isEmpty()) {
            storedEntityData = previousStoredEntityData;
            reloadMerchantVillagerFromStoredData(villager);
            villager.setTradingPlayer(player);
            return false;
        }
        if (openMenu != null && paymentReturnPlan != null) {
            openMenu.commitPaymentReturn(player, paymentReturnPlan);
            openMenu.setSelectionHint(MerchantOfferComparator.findEquivalentIndex(offers, previouslySelected));
        }

        saveProxyToStoredData();
        tradeRefreshTicks = 0;
        markOffersChanged();
        sendMenuSync(player, villager);
        return true;
    }

    public InteractionResult openTrade(Player player) {
        if (!hasStoredEntity()) {
            return InteractionResult.SUCCESS_SERVER;
        }

        if (!hasVillager()) {
            return InteractionResult.SUCCESS_SERVER;
        }

        refreshVillagerProfessionFromPoi();
        TradingCellVillager villager = getOrCreateMerchantVillager();
        if (villager == null) {
            return InteractionResult.FAIL;
        }

        if (villager.isBaby()) {
            return InteractionResult.SUCCESS_SERVER;
        }

        MerchantOffers offers = villager.getOffers();
        if (villagerTradeService.infiniteTrades()) {
            resetUsedOffers(offers);
        }
        if (offers.isEmpty()) {
            return InteractionResult.SUCCESS_SERVER;
        }

        if (!(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResult.SUCCESS;
        }

        registerTradingPlayer(player);
        villager.preparePrices(player);
        villager.setTradingPlayer(player);
        serverPlayer.openMenu(new SimpleMenuProvider(
                (containerId, inventory, menuPlayer) -> new VillagerTradingCellMenu(
                        containerId,
                        inventory,
                        villager
                ),
                villager.getDisplayName()
        )).ifPresent(containerId -> sendMenuSync(player, villager));
        return InteractionResult.SUCCESS_SERVER;
    }

    public boolean canResetTrades() {
        if (!hasVillager() || storedEntityData == null || isVillagerBaby(storedEntityData)) {
            return false;
        }
        TradingCellVillager villager = getOrCreateMerchantVillager();
        return villager != null
                && villager.getVillagerXp() == 0
                && !isVillagerProfessionPersistent(storedEntityData)
                && getProfessionForPoiStack(storedPoiStack) != null;
    }

    private void sendMenuSync(Player player, TradingCellVillager villager) {
        if (!(player instanceof ServerPlayer serverPlayer)
                || !(serverPlayer.containerMenu instanceof VillagerTradingCellMenu menu)) {
            return;
        }
        MerchantOffers currentOffers = villager.getOffers();
        VillagerData currentData = villager.getVillagerData();
        menu.applyServerState(
                currentOffers,
                currentData,
                currentData.level(),
                villager.getVillagerXp(),
                storedExperience,
                menu.selectedOfferIndex(),
                villager.showProgressBar(),
                villager.canRestock(),
                canResetTrades(),
                offersRevision
        );
        PacketDistributor.sendToPlayer(
                serverPlayer,
                new TradingCellMenuSyncPayload(
                        menu.containerId,
                        currentOffers,
                        currentData,
                        currentData.level(),
                        villager.getVillagerXp(),
                        storedExperience,
                        menu.selectedOfferIndex(),
                        villager.showProgressBar(),
                        villager.canRestock(),
                        canResetTrades(),
                        offersRevision
                )
        );
    }

    public void discardContentsAfterBlockDrop() {
        storedEntityKind = null;
        storedEntityData = null;
        storedPoiStack = ItemStack.EMPTY;
        merchantVillager = null;
        tradeRefreshTicks = 0;
        storedExperience = 0;
        setChanged();
    }

    @Override
    protected void loadAdditional(@NonNull ValueInput input) {
        super.loadAdditional(input);
        storedEntityKind = input.getString(ENTITY_KIND_TAG).map(StoredEntityKind::fromId).orElse(null);
        storedEntityData = input.read(ENTITY_DATA_TAG, CompoundTag.CODEC).orElse(null);
        storedPoiStack = input.read(POI_STACK_TAG, ItemStack.CODEC).orElse(ItemStack.EMPTY);
        tradeRefreshTicks = Math.max(0, input.getIntOr(TRADE_REFRESH_TICKS_TAG, 0));
        storedExperience = Math.max(0, input.getIntOr(STORED_EXPERIENCE_TAG, 0));

        // Backwards compatibility with saves made by the earlier villager-only version.
        if (storedEntityData == null) {
            storedEntityData = input.read(LEGACY_VILLAGER_DATA_TAG, CompoundTag.CODEC).orElse(null);
            if (storedEntityData != null && !storedEntityData.isEmpty()) {
                storedEntityKind = StoredEntityKind.VILLAGER;
            }
        }

        if (storedEntityKind == null || storedEntityData == null || storedEntityData.isEmpty()) {
            storedEntityKind = null;
            storedEntityData = null;
        }
        if (storedPoiStack.isEmpty()) {
            storedPoiStack = ItemStack.EMPTY;
        }

        merchantVillager = null;
    }

    @Override
    protected void saveAdditional(@NonNull ValueOutput output) {
        saveProxyToStoredData();
        super.saveAdditional(output);
        if (storedEntityKind != null && storedEntityData != null && !storedEntityData.isEmpty()) {
            output.putString(ENTITY_KIND_TAG, storedEntityKind.id);
            output.store(ENTITY_DATA_TAG, CompoundTag.CODEC, storedEntityData);
        }
        if (!storedPoiStack.isEmpty()) {
            output.store(POI_STACK_TAG, ItemStack.CODEC, storedPoiStack);
        }
        if (tradeRefreshTicks > 0) {
            output.putInt(TRADE_REFRESH_TICKS_TAG, tradeRefreshTicks);
        }
        if (storedExperience > 0) {
            output.putInt(STORED_EXPERIENCE_TAG, storedExperience);
        }
    }

    @Override
    public @Nullable Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveCustomOnly(registries);
    }

    private void setStoredEntity(StoredEntityKind kind, CompoundTag entityData) {
        storedEntityKind = kind;
        storedEntityData = entityData.copy();
        merchantVillager = null;
        tradeRefreshTicks = 0;
        markChangedAndSync();
    }

    private @Nullable TradingCellVillager getOrCreateMerchantVillager() {
        if (merchantVillager != null) {
            return merchantVillager;
        }

        if (level == null || !hasVillager() || storedEntityData == null) {
            return null;
        }

        TradingCellVillager villager = new TradingCellVillager(level, this);
        villager.load(TagValueInput.create(ProblemReporter.DISCARDING, level.registryAccess(), storedEntityData.copy()));
        villager.setPos(worldPosition.getX() + 0.5D, worldPosition.getY(), worldPosition.getZ() + 0.5D);
        villager.setPersistenceRequired();
        merchantVillager = villager;
        return merchantVillager;
    }

    private void reloadMerchantVillagerFromStoredData(TradingCellVillager villager) {
        if (level == null || storedEntityData == null) {
            return;
        }
        villager.load(TagValueInput.create(ProblemReporter.DISCARDING, level.registryAccess(), storedEntityData.copy()));
        villager.setPos(worldPosition.getX() + 0.5D, worldPosition.getY(), worldPosition.getZ() + 0.5D);
        villager.setPersistenceRequired();
        merchantVillager = villager;
    }

    private static @Nullable Entity createEntity(Level level, StoredEntityKind kind, CompoundTag entityData, BlockPos position) {
        return CapturedMobStackAdapter.createEntity(capturedKind(kind), level, entityData, position);
    }

    private void saveProxyToStoredData() {
        if (merchantVillager != null && storedEntityKind == StoredEntityKind.VILLAGER) {
            storedEntityData = CapturedMobStackAdapter.createVillagerData(merchantVillager);
        }
    }

    private static CapturedMobKind capturedKind(StoredEntityKind kind) {
        return kind == StoredEntityKind.VILLAGER
                ? CapturedMobKind.VILLAGER
                : CapturedMobKind.PIGLIN;
    }

    private void refreshVillagerProfessionFromPoi() {
        if (!hasVillager() || storedEntityData == null) {
            return;
        }

        saveProxyToStoredData();
        if (isVillagerProfessionPersistent(storedEntityData)) {
            return;
        }
        boolean changed;
        if (isVillagerBaby(storedEntityData)) {
            changed = clearVillagerProfession(storedEntityData);
        } else {
            String professionId = getProfessionForPoiStack(storedPoiStack);
            changed = professionId == null
                    ? clearVillagerProfession(storedEntityData)
                    : setVillagerProfession(storedEntityData, professionId);
        }
        if (changed) {
            merchantVillager = null;
            tradeRefreshTicks = 0;
            markChangedAndSync();
        }
    }

    private void clearTransientVillagerProfession() {
        if (!hasVillager() || storedEntityData == null) {
            return;
        }

        saveProxyToStoredData();
        if (!isVillagerProfessionPersistent(storedEntityData)) {
            if (clearVillagerProfession(storedEntityData)) {
                merchantVillager = null;
                tradeRefreshTicks = 0;
                markChangedAndSync();
            }
        }
    }

    private boolean hasPersistentVillagerProfession() {
        return hasVillager() && storedEntityData != null && isVillagerProfessionPersistent(storedEntityData);
    }

    private static boolean isVillagerProfessionPersistent(CompoundTag villagerData) {
        if (villagerData.getInt(XP_TAG).orElse(0) > 0) {
            return true;
        }

        return villagerData.getCompound(VILLAGER_DATA_TAG)
                .flatMap(data -> data.getInt(LEVEL_TAG))
                .map(level -> level > 1)
                .orElse(false);
    }

    private static boolean isVillagerBaby(CompoundTag villagerData) {
        return villagerData.getInt(AGE_TAG).orElse(0) < 0;
    }

    private static boolean setVillagerProfession(CompoundTag villagerData, String professionId) {
        CompoundTag data = villagerData.getCompound(VILLAGER_DATA_TAG).map(CompoundTag::copy).orElseGet(CompoundTag::new);
        String previousProfession = data.getString(PROFESSION_TAG).orElse(NONE_PROFESSION);
        boolean changed = !professionId.equals(previousProfession);
        data.putString(PROFESSION_TAG, professionId);
        if (data.getInt(LEVEL_TAG).isEmpty()) {
            data.putInt(LEVEL_TAG, 1);
        }
        villagerData.put(VILLAGER_DATA_TAG, data);
        if (changed) {
            villagerData.remove("Offers");
        }
        return changed;
    }

    private static boolean clearVillagerProfession(CompoundTag villagerData) {
        boolean changed = setVillagerProfession(villagerData, NONE_PROFESSION);
        if (villagerData.getInt(XP_TAG).orElse(0) != 0) {
            villagerData.putInt(XP_TAG, 0);
            changed = true;
        }
        return changed;
    }

    private @Nullable String getProfessionForPoiStack(ItemStack stack) {
        if (stack.isEmpty() || !(stack.getItem() instanceof BlockItem blockItem) || level == null) {
            return null;
        }

        return blockItem.getBlock()
                .getStateDefinition()
                .getPossibleStates()
                .stream()
                .map(this::getProfessionForPoiState)
                .filter(Objects::nonNull)
                .findFirst()
                .orElse(null);
    }

    private @Nullable String getProfessionForPoiState(BlockState poiState) {
        Holder<PoiType> poiType = PoiTypes.forState(poiState).orElse(null);
        if (poiType == null) {
            return null;
        }

        return level.registryAccess()
                .lookupOrThrow(Registries.VILLAGER_PROFESSION)
                .listElements()
                .filter(profession -> !profession.is(VillagerProfession.NONE))
                .filter(profession -> !profession.is(VillagerProfession.NITWIT))
                .filter(profession -> profession.value().heldJobSite().test(poiType)
                        || profession.value().acquirableJobSite().test(poiType))
                .findFirst()
                .flatMap(Holder::unwrapKey)
                .map(key -> key.identifier().toString())
                .orElse(null);
    }

    private void addStoredExperience(int amount, @Nullable Player tradingPlayer) {
        if (amount <= 0) {
            return;
        }
        storedExperience = (int) Math.min(Integer.MAX_VALUE, (long) storedExperience + amount);
        setChanged();
        if (tradingPlayer != null) {
            syncStoredExperience(tradingPlayer);
        }
    }

    private void extractStoredExperience(Player player, byte mode) {
        if (level == null || level.isClientSide()) {
            return;
        }
        if (storedExperience > 0) {
            int extracted = storedExperience;
            if (mode == com.cosmocraft.trading_cells.platform.neoforge.network.ExtractTradingCellExperiencePayload.NEXT_LEVEL) {
                int needed = Math.max(
                        1,
                        Mth.ceil((1.0F - player.experienceProgress) * player.getXpNeededForNextLevel())
                );
                extracted = Math.min(storedExperience, needed);
            }
            storedExperience -= extracted;
            player.giveExperiencePoints(extracted);
            markChangedAndSync();
        }
        syncStoredExperience(player);
        TradingCellVillager villager = getOrCreateMerchantVillager();
        if (villager != null) {
            sendMenuSync(player, villager);
        }
    }

    private void syncStoredExperience(Player player) {
        if (player instanceof ServerPlayer serverPlayer) {
            PacketDistributor.sendToPlayer(
                    serverPlayer,
                    new TradingCellExperiencePayload(serverPlayer.containerMenu.containerId, storedExperience)
            );
        }
    }

    private void registerTradingPlayer(Player player) {
        if (level != null) {
            OPEN_TRADING_CELLS_BY_PLAYER.put(player.getUUID(), GlobalPos.of(level.dimension(), worldPosition));
        }
    }

    private static void unregisterTradingPlayer(UUID playerId) {
        OPEN_TRADING_CELLS_BY_PLAYER.remove(playerId);
    }


    private static ItemStack createSingleCapturerTarget(ItemStack heldStack) {
        if (heldStack.getCount() <= 1) {
            return heldStack;
        }
        return new ItemStack(heldStack.getItem());
    }

    private static void finishStackedExtraction(Player player, ItemStack heldStack, ItemStack targetStack) {
        if (targetStack == heldStack) {
            return;
        }

        heldStack.shrink(1);
        if (!player.getInventory().add(targetStack)) {
            player.drop(targetStack, false);
        }
    }

    private void clearStoredEntity() {
        storedEntityKind = null;
        storedEntityData = null;
        merchantVillager = null;
        tradeRefreshTicks = 0;
        markChangedAndSync();
    }


    private void tickOpenTradingPriceSync() {
        if (!(level instanceof ServerLevel) || merchantVillager == null || merchantVillager.getTradingPlayer() == null) {
            return;
        }
        if (level.getGameTime() % 20L == 0L) {
            merchantVillager.sendCurrentOffers();
            saveProxyToStoredData();
        }
    }

    private void tickTradeRefresh() {
        if (!(level instanceof ServerLevel serverLevel) || !hasEmployedAdultVillager()) {
            if (tradeRefreshTicks != 0) {
                tradeRefreshTicks = 0;
                setChanged();
            }
            return;
        }

        TradingCellVillager villager = getOrCreateMerchantVillager();
        if (villager == null) {
            tradeRefreshTicks = 0;
            return;
        }

        if (villagerTradeService.infiniteTrades()) {
            tradeRefreshTicks = 0;
            if (resetUsedOffers(villager.getOffers())) {
                saveProxyToStoredData();
                markOffersChanged();
                villager.sendCurrentOffers();
            }
            return;
        }

        tradeRefreshTicks++;
        if (tradeRefreshTicks < RESTOCK_CHECK_INTERVAL_TICKS) {
            if (tradeRefreshTicks % 20 == 0) {
                setChanged();
            }
            return;
        }

        tradeRefreshTicks = 0;
        boolean restocked = villager.shouldRestock(serverLevel);
        if (restocked) {
            villager.restock();
        }
        // shouldRestock also updates the villager's internal day/restock tracking,
        // so persist it even when this particular check did not replenish stock.
        saveProxyToStoredData();
        if (restocked) {
            markOffersChanged();
            villager.sendCurrentOffers();
        } else {
            markChangedAndSync();
        }
    }

    private static boolean resetUsedOffers(MerchantOffers offers) {
        boolean changed = false;
        for (MerchantOffer offer : offers) {
            if (offer.needsRestock()) {
                offer.resetUses();
                changed = true;
            }
        }
        return changed;
    }

    private boolean hasEmployedAdultVillager() {
        if (!hasVillager() || storedEntityData == null || isVillagerBaby(storedEntityData)) {
            return false;
        }
        String profession = storedEntityData.getCompound(VILLAGER_DATA_TAG)
                .flatMap(data -> data.getString(PROFESSION_TAG))
                .orElse(NONE_PROFESSION);
        return !profession.isBlank() && !NONE_PROFESSION.equals(profession);
    }

    private void markChangedAndSync() {
        setChanged();
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), Block.UPDATE_CLIENTS);
        }
    }

    private void markOffersChanged() {
        offersRevision++;
        markChangedAndSync();
    }

    private boolean isPlayerStillValid(Player player) {
        return !isRemoved()
                && level != null
                && level.getBlockEntity(worldPosition) == this
                && player.distanceToSqr(
                        worldPosition.getX() + 0.5D,
                        worldPosition.getY() + 0.5D,
                        worldPosition.getZ() + 0.5D
                ) <= 64.0D;
    }

    private enum StoredEntityKind {
        VILLAGER("villager"),
        PIGLIN("piglin");

        private final String id;

        StoredEntityKind(String id) {
            this.id = id;
        }

        private static @Nullable StoredEntityKind fromId(String id) {
            for (StoredEntityKind kind : values()) {
                if (kind.id.equals(id)) {
                    return kind;
                }
            }
            return null;
        }
    }

    private static final class TradingCellVillager extends Villager {
        private final VillagerTradingCellBlockEntity owner;
        private @Nullable UUID currentTradingPlayerId;

        private TradingCellVillager(Level level, VillagerTradingCellBlockEntity owner) {
            super(CapturedMobStackAdapter.villagerType(), level);
            this.owner = owner;
        }

        @Override
        public void setTradingPlayer(@Nullable Player player) {
            super.setTradingPlayer(player);
            if (player == null) {
                if (currentTradingPlayerId != null) {
                    unregisterTradingPlayer(currentTradingPlayerId);
                    currentTradingPlayerId = null;
                }
                owner.saveProxyToStoredData();
                owner.markChangedAndSync();
            } else {
                currentTradingPlayerId = player.getUUID();
                owner.registerTradingPlayer(player);
            }
        }

        @Override
        protected void rewardTradeXp(@NonNull MerchantOffer offer) {
            setVillagerXp(getVillagerXp() + offer.getXp());
            if (!offer.shouldRewardExp()) {
                return;
            }

            int rewardExperience = 3 + getRandom().nextInt(4);
            int currentLevel = getVillagerData().level();
            if (VillagerData.canLevelUp(currentLevel)
                    && getVillagerXp() >= VillagerData.getMaxXpPerLevel(currentLevel)) {
                rewardExperience += 5;
            }
            owner.addStoredExperience(rewardExperience, getTradingPlayer());
        }

        @Override
        public void notifyTrade(@NonNull MerchantOffer offer) {
            Player tradingPlayer = getTradingPlayer();
            boolean infiniteTrades = owner.villagerTradeService.infiniteTrades();
            super.notifyTrade(offer);
            markTemporaryDiscount(offer);
            if (infiniteTrades) {
                offer.resetUses();
            }
            forceCareerLevelUpdate();
            if (tradingPlayer != null && level() instanceof ServerLevel serverLevel) {
                serverLevel.onReputationEvent(ReputationEventType.TRADE, tradingPlayer, this);
                preparePrices(tradingPlayer);
            }
            owner.saveProxyToStoredData();
            owner.markOffersChanged();
            if (tradingPlayer != null) {
                sendCurrentOffers();
            }
        }

        private void sendCurrentOffers() {
            Player tradingPlayer = getTradingPlayer();
            if (tradingPlayer == null || getOffers().isEmpty()) {
                return;
            }
            if (owner.villagerTradeService.infiniteTrades()) {
                resetUsedOffers(getOffers());
            }
            preparePrices(tradingPlayer);
            if (tradingPlayer.containerMenu instanceof VillagerTradingCellMenu) {
                owner.sendMenuSync(tradingPlayer, this);
            } else {
                tradingPlayer.sendMerchantOffers(
                        tradingPlayer.containerMenu.containerId,
                        getOffers(),
                        getVillagerData().level(),
                        getVillagerXp(),
                        showProgressBar(),
                        canRestock()
                );
            }
        }

        private void preparePrices(Player player) {
            MerchantOffers offers = getOffers();
            for (MerchantOffer offer : offers) {
                offer.resetSpecialPriceDiff();
            }

            int reputation = getPlayerReputation(player);
            int careerDiscount = Math.max(0, getVillagerData().level() - 1);
            int cureDiscount = getPersistentData().getInt(CURE_DISCOUNT_TAG).orElse(0);
            long temporaryMask = activeTemporaryDiscountMask();
            MobEffectInstance hero = player.getEffect(MobEffects.HERO_OF_THE_VILLAGE);
            for (MerchantOffer offer : offers) {
                if (reputation != 0) {
                    offer.addToSpecialPriceDiff(-Mth.floor(reputation * offer.getPriceMultiplier()));
                }
                if (careerDiscount > 0) {
                    offer.addToSpecialPriceDiff(-careerDiscount);
                }
                if (cureDiscount > 0) {
                    offer.addToSpecialPriceDiff(-cureDiscount);
                }
                int offerIndex = offers.indexOf(offer);
                if (TradeDiscountPolicy.appliesTo(temporaryMask, offerIndex)) {
                    offer.addToSpecialPriceDiff(-TradeDiscountPolicy.TEMPORARY_DISCOUNT_PER_OFFER);
                }
                if (hero != null) {
                    double modifier = 0.3D + 0.0625D * hero.getAmplifier();
                    int reduction = (int) Math.floor(modifier * offer.getBaseCostA().getCount());
                    offer.addToSpecialPriceDiff(-Math.max(reduction, 1));
                }
            }
        }


        private void markTemporaryDiscount(MerchantOffer offer) {
            int offerIndex = getOffers().indexOf(offer);
            long mask = getPersistentData().getLong(TEMPORARY_DISCOUNT_MASK_TAG).orElse(0L);
            long updated = TradeDiscountPolicy.markOffer(mask, offerIndex);
            getPersistentData().putLong(TEMPORARY_DISCOUNT_MASK_TAG, updated);
            getPersistentData().putLong(
                    TEMPORARY_DISCOUNT_EXPIRES_TAG,
                    level().getGameTime() + TradeDiscountPolicy.TEMPORARY_DISCOUNT_TICKS
            );
        }

        private long activeTemporaryDiscountMask() {
            long expiresAt = getPersistentData().getLong(TEMPORARY_DISCOUNT_EXPIRES_TAG).orElse(0L);
            if (TradeDiscountPolicy.expired(expiresAt, level().getGameTime())) {
                getPersistentData().remove(TEMPORARY_DISCOUNT_MASK_TAG);
                getPersistentData().remove(TEMPORARY_DISCOUNT_EXPIRES_TAG);
                return 0L;
            }
            return getPersistentData().getLong(TEMPORARY_DISCOUNT_MASK_TAG).orElse(0L);
        }

        private void forceCareerLevelUpdate() {
            if (!(level() instanceof ServerLevel serverLevel)) {
                return;
            }

            while (VillagerData.canLevelUp(getVillagerData().level())
                    && getVillagerXp() >= VillagerData.getMaxXpPerLevel(getVillagerData().level())) {
                setVillagerData(getVillagerData().withLevel(getVillagerData().level() + 1));
                updateTrades(serverLevel);
            }
        }

        private void rerollUnlockedTrades(ServerLevel serverLevel) {
            int unlockedLevel = getVillagerData().level();
            getOffers().clear();
            for (int level = 1; level <= unlockedLevel; level++) {
                setVillagerData(getVillagerData().withLevel(level));
                updateTrades(serverLevel);
            }
            setVillagerData(getVillagerData().withLevel(unlockedLevel));
        }

        @Override
        public void notifyTradeUpdated(@NonNull ItemStack stack) {
            super.notifyTradeUpdated(stack);
            owner.saveProxyToStoredData();
            owner.markChangedAndSync();
        }

        @Override
        public boolean stillValid(@NonNull Player player) {
            return owner.isPlayerStillValid(player);
        }
    }
}
