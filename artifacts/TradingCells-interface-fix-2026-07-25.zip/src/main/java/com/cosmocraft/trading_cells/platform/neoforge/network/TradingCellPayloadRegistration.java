package com.cosmocraft.trading_cells.platform.neoforge.network;

import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class TradingCellPayloadRegistration {
    private TradingCellPayloadRegistration() {
    }

    public static void onRegisterPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("2");
        registrar.playToServer(ResetTradesPayload.TYPE, ResetTradesPayload.STREAM_CODEC, ResetTradesPayload::handle);
        registrar.playToServer(
                SelectAutotraderOfferPayload.TYPE,
                SelectAutotraderOfferPayload.STREAM_CODEC,
                SelectAutotraderOfferPayload::handle
        );
        registrar.playToServer(
                SelectTradingCellOfferPayload.TYPE,
                SelectTradingCellOfferPayload.STREAM_CODEC,
                SelectTradingCellOfferPayload::handle
        );
        registrar.playToServer(
                ExtractTradingCellExperiencePayload.TYPE,
                ExtractTradingCellExperiencePayload.STREAM_CODEC,
                ExtractTradingCellExperiencePayload::handle
        );
        registrar.playToClient(TradingCellExperiencePayload.TYPE, TradingCellExperiencePayload.STREAM_CODEC);
        registrar.playToClient(TradingCellMenuSyncPayload.TYPE, TradingCellMenuSyncPayload.STREAM_CODEC);
        registrar.playToClient(AutotraderMenuSyncPayload.TYPE, AutotraderMenuSyncPayload.STREAM_CODEC);
    }
}
