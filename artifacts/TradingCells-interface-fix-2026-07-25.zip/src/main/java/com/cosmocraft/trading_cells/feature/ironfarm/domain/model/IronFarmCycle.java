package com.cosmocraft.trading_cells.feature.ironfarm.domain.model;

public record IronFarmCycle(
        int cycleTicks,
        int oneVillagerMultiplier,
        int twoVillagerMultiplier,
        int threeVillagerMultiplier,
        int golemAttackTicks,
        int golemHitInterval,
        int golemRedFlashTicks
) {
    public IronFarmCycle {
        cycleTicks = Math.max(1, cycleTicks);
        oneVillagerMultiplier = Math.max(0, oneVillagerMultiplier);
        twoVillagerMultiplier = Math.max(0, twoVillagerMultiplier);
        threeVillagerMultiplier = Math.max(0, threeVillagerMultiplier);
        golemAttackTicks = Math.max(0, Math.min(cycleTicks, golemAttackTicks));
        golemHitInterval = Math.max(1, golemHitInterval);
        golemRedFlashTicks = Math.max(0, Math.min(golemHitInterval - 1, golemRedFlashTicks));
    }

    public int multiplier(int villagerCount) {
        return switch (Math.max(0, Math.min(3, villagerCount))) {
            case 1 -> oneVillagerMultiplier;
            case 2 -> twoVillagerMultiplier;
            case 3 -> threeVillagerMultiplier;
            default -> 0;
        };
    }

    public boolean isGolemVisible(int currentTicks) {
        return currentTicks >= cycleTicks - golemAttackTicks;
    }

    public boolean isGolemHitTick(int currentTicks) {
        if (!isGolemVisible(currentTicks) || currentTicks >= cycleTicks) {
            return false;
        }
        return (currentTicks - (cycleTicks - golemAttackTicks)) % golemHitInterval == 0;
    }

    public boolean hasRedHitFlash(int currentTicks) {
        if (!isGolemVisible(currentTicks)) {
            return false;
        }
        int elapsed = currentTicks - (cycleTicks - golemAttackTicks);
        return elapsed % golemHitInterval < golemRedFlashTicks;
    }

    public boolean isRedHitFlashEnding(int currentTicks) {
        if (!isGolemVisible(currentTicks)) {
            return false;
        }
        int elapsed = currentTicks - (cycleTicks - golemAttackTicks);
        return elapsed % golemHitInterval == golemRedFlashTicks;
    }
}
