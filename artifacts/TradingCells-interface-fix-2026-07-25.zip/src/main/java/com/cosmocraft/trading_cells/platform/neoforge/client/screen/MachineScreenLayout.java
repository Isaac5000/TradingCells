package com.cosmocraft.trading_cells.platform.neoforge.client.screen;

import com.cosmocraft.trading_cells.platform.neoforge.menu.MachineMenuLayout;
import com.cosmocraft.trading_cells.platform.neoforge.menu.PlayerEquipmentSlots;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/** Shared geometry and rendering for every custom machine screen. */
public final class MachineScreenLayout {
    public static final int WIDTH = MachineMenuLayout.WIDTH;
    public static final int HEIGHT = MachineMenuLayout.HEIGHT;
    public static final int CONTENT_X = MachineMenuLayout.CONTENT_X;
    public static final int CONTENT_WIDTH = MachineMenuLayout.CONTENT_WIDTH;

    public static final int TITLE_Y = MachineMenuLayout.TITLE_Y;
    public static final int PLAYER_INVENTORY_X = MachineMenuLayout.PLAYER_INVENTORY_X;
    public static final int PLAYER_INVENTORY_SLOT_Y = MachineMenuLayout.PLAYER_INVENTORY_SLOT_Y;
    public static final int PLAYER_INVENTORY_LABEL_X = MachineMenuLayout.PLAYER_INVENTORY_LABEL_X;
    public static final int PLAYER_INVENTORY_LABEL_Y = MachineMenuLayout.PLAYER_INVENTORY_LABEL_Y;

    public static final int PROGRESS_FRAME_WIDTH = 69;
    public static final int PROGRESS_FRAME_HEIGHT = 13;
    /** The fill starts inside the frame, one pixel farther right than before. */
    public static final int PROGRESS_FILL_X_OFFSET = 2;
    /** The fill now reaches the top interior row of the frame. */
    public static final int PROGRESS_FILL_Y_OFFSET = 2;
    /** One pixel shorter so the right end remains inside the decorative frame. */
    public static final int PROGRESS_FILL_WIDTH = 66;
    /** Fills the complete nine-pixel interior, including its bottom row. */
    public static final int PROGRESS_FILL_HEIGHT = 9;

    private static final int TILE_SIZE = 16;
    private static final int OUTER_MARGIN = 4;
    private static final int TITLE_PANEL_X = 6;
    private static final int TITLE_PANEL_Y = 4;
    private static final int TITLE_PANEL_HEIGHT = 16;
    private static final int MACHINE_PANEL_X = OUTER_MARGIN;
    private static final int MACHINE_PANEL_Y = 22;
    private static final int MACHINE_PANEL_WIDTH = WIDTH - OUTER_MARGIN * 2;
    private static final int MACHINE_PANEL_HEIGHT = 95;
    private static final int INVENTORY_HEADER_Y = 119;
    private static final int INVENTORY_HEADER_HEIGHT = 14;
    private static final int INVENTORY_PANEL_Y = 133;
    private static final int INVENTORY_PANEL_LEFT = PLAYER_INVENTORY_X - 4;
    private static final int INVENTORY_PANEL_RIGHT = WIDTH - 4;

    private MachineScreenLayout() {
    }

    public static int machineX(int localX) {
        return MachineMenuLayout.machineX(localX);
    }

    public static void drawBackground(
            GuiGraphicsExtractor graphics,
            int x,
            int y,
            Identifier surfaceTexture,
            MachineScreenTheme theme
    ) {
        drawOuterFrame(graphics, x, y, theme);
        drawTitlePanel(graphics, x, y, theme);
        drawMachinePanel(graphics, x, y, surfaceTexture, theme);
        drawInventoryPanel(graphics, x, y, theme);
        drawPlayerInventory(graphics, x, y, theme);
        drawEquipmentPanel(graphics, x, y, theme);
    }

    public static void drawSingleTextureBackground(
            GuiGraphicsExtractor graphics,
            int x,
            int y,
            Identifier surfaceTexture,
            MachineScreenTheme theme
    ) {
        drawBackground(graphics, x, y, surfaceTexture, theme);
    }

    public static void drawLabels(
            GuiGraphicsExtractor graphics,
            Font font,
            Component title,
            Component inventoryTitle,
            MachineScreenTheme theme
    ) {
        graphics.text(
                font,
                title,
                (WIDTH - font.width(title)) / 2,
                TITLE_Y,
                theme.titleText(),
                true
        );
        graphics.text(
                font,
                inventoryTitle,
                PLAYER_INVENTORY_LABEL_X,
                PLAYER_INVENTORY_LABEL_Y,
                theme.titleText(),
                false
        );
    }

    public static void drawPlayerInventory(
            GuiGraphicsExtractor graphics,
            int x,
            int y,
            MachineScreenTheme theme
    ) {
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                drawSlot(
                        graphics,
                        x,
                        y,
                        PLAYER_INVENTORY_X + column * 18,
                        PLAYER_INVENTORY_SLOT_Y + row * 18,
                        theme
                );
            }
        }
        for (int column = 0; column < 9; column++) {
            drawSlot(
                    graphics,
                    x,
                    y,
                    PLAYER_INVENTORY_X + column * 18,
                    PLAYER_INVENTORY_SLOT_Y + 58,
                    theme
            );
        }
    }

    public static void drawEquipmentPanel(
            GuiGraphicsExtractor graphics,
            int x,
            int y,
            MachineScreenTheme theme
    ) {
        int panelLeft = x + PlayerEquipmentSlots.X - 3;
        int panelTop = y + PlayerEquipmentSlots.HEAD_Y - 3;
        int panelRight = x + PlayerEquipmentSlots.X + 19;
        int panelBottom = y + PlayerEquipmentSlots.OFFHAND_Y + 19;

        graphics.fill(panelLeft, panelTop, panelRight, panelBottom, theme.frameDark());
        graphics.fill(panelLeft + 1, panelTop + 1, panelRight - 1, panelBottom - 1, theme.frame());
        graphics.outline(
                panelLeft,
                panelTop,
                panelRight - panelLeft,
                panelBottom - panelTop,
                theme.frameLight()
        );

        drawSlot(graphics, x, y, PlayerEquipmentSlots.X, PlayerEquipmentSlots.HEAD_Y, theme);
        drawSlot(graphics, x, y, PlayerEquipmentSlots.X, PlayerEquipmentSlots.CHEST_Y, theme);
        drawSlot(graphics, x, y, PlayerEquipmentSlots.X, PlayerEquipmentSlots.LEGS_Y, theme);
        drawSlot(graphics, x, y, PlayerEquipmentSlots.X, PlayerEquipmentSlots.FEET_Y, theme);
        drawSlot(graphics, x, y, PlayerEquipmentSlots.X, PlayerEquipmentSlots.OFFHAND_Y, theme);
    }

    /**
     * Draws an 18x18 slot whose one-pixel frame is entirely outside the
     * 16x16 item area. Items therefore never cover the decorative border.
     */
    public static void drawSlot(
            GuiGraphicsExtractor graphics,
            int screenX,
            int screenY,
            int slotX,
            int slotY,
            MachineScreenTheme theme
    ) {
        SlotRenderer.drawAtItemPosition(
                graphics,
                screenX,
                screenY,
                slotX,
                slotY,
                new SlotRenderer.Palette(
                        theme.slot(),
                        theme.frameDark(),
                        theme.slotInner(),
                        theme.slotHighlight()
                )
        );
    }

    public static void drawEmptySlotSprite(
            GuiGraphicsExtractor graphics,
            int screenX,
            int screenY,
            int slotX,
            int slotY,
            Identifier sprite
    ) {
        graphics.blitSprite(
                RenderPipelines.GUI_TEXTURED,
                sprite,
                screenX + slotX,
                screenY + slotY,
                16,
                16
        );
    }

    public static void drawProgressFrame(
            GuiGraphicsExtractor graphics,
            int x,
            int y,
            MachineScreenTheme theme
    ) {
        graphics.fill(x, y, x + PROGRESS_FRAME_WIDTH, y + PROGRESS_FRAME_HEIGHT, theme.frameDark());
        graphics.fill(x + 1, y + 1, x + PROGRESS_FRAME_WIDTH - 1, y + PROGRESS_FRAME_HEIGHT - 1, theme.frameLight());
        graphics.fill(x + 2, y + 2, x + PROGRESS_FRAME_WIDTH - 2, y + PROGRESS_FRAME_HEIGHT - 2, theme.slotInner());
    }

    private static void drawOuterFrame(
            GuiGraphicsExtractor graphics,
            int x,
            int y,
            MachineScreenTheme theme
    ) {
        graphics.fill(x, y, x + WIDTH, y + HEIGHT, theme.frameDark());
        graphics.fill(x + 2, y + 2, x + WIDTH - 2, y + HEIGHT - 2, theme.frame());
        graphics.outline(x, y, WIDTH, HEIGHT, theme.frameLight());
        graphics.outline(x + 2, y + 2, WIDTH - 4, HEIGHT - 4, theme.frameDark());
    }

    private static void drawTitlePanel(
            GuiGraphicsExtractor graphics,
            int x,
            int y,
            MachineScreenTheme theme
    ) {
        int left = x + TITLE_PANEL_X;
        int top = y + TITLE_PANEL_Y;
        int right = x + WIDTH - TITLE_PANEL_X;
        int bottom = top + TITLE_PANEL_HEIGHT;

        graphics.fill(left, top, right, bottom, theme.frameDark());
        graphics.fill(left + 2, top + 2, right - 2, bottom - 2, theme.slotInner());
        graphics.outline(left, top, right - left, TITLE_PANEL_HEIGHT, theme.frameLight());
        graphics.outline(left + 2, top + 2, right - left - 4, TITLE_PANEL_HEIGHT - 4, theme.frame());
    }

    private static void drawMachinePanel(
            GuiGraphicsExtractor graphics,
            int x,
            int y,
            Identifier surfaceTexture,
            MachineScreenTheme theme
    ) {
        int panelX = x + MACHINE_PANEL_X;
        int panelY = y + MACHINE_PANEL_Y;
        graphics.fill(
                panelX - 1,
                panelY - 1,
                panelX + MACHINE_PANEL_WIDTH + 1,
                panelY + MACHINE_PANEL_HEIGHT + 1,
                theme.frameDark()
        );
        tile(graphics, surfaceTexture, panelX, panelY, MACHINE_PANEL_WIDTH, MACHINE_PANEL_HEIGHT);
        graphics.fill(panelX, panelY, panelX + MACHINE_PANEL_WIDTH, panelY + MACHINE_PANEL_HEIGHT, 0x24000000);
        graphics.outline(panelX - 1, panelY - 1, MACHINE_PANEL_WIDTH + 2, MACHINE_PANEL_HEIGHT + 2, theme.frameLight());
    }

    private static void drawInventoryPanel(
            GuiGraphicsExtractor graphics,
            int x,
            int y,
            MachineScreenTheme theme
    ) {
        int left = x + INVENTORY_PANEL_LEFT;
        int right = x + INVENTORY_PANEL_RIGHT;

        graphics.fill(left, y + INVENTORY_HEADER_Y, right, y + INVENTORY_HEADER_Y + INVENTORY_HEADER_HEIGHT, theme.frameDark());
        graphics.fill(
                left + 1,
                y + INVENTORY_HEADER_Y + 1,
                right - 1,
                y + INVENTORY_HEADER_Y + INVENTORY_HEADER_HEIGHT - 1,
                theme.frame()
        );
        graphics.outline(
                left,
                y + INVENTORY_HEADER_Y,
                right - left,
                INVENTORY_HEADER_HEIGHT,
                theme.frameLight()
        );

        // Reach the bottom of the GUI just like the equipment rail. This
        // removes the short, unfinished strip below the hotbar.
        graphics.fill(left, y + INVENTORY_PANEL_Y, right, y + HEIGHT, theme.frameDark());
        graphics.fill(left + 2, y + INVENTORY_PANEL_Y + 2, right - 2, y + HEIGHT - 2, theme.frame());
        graphics.outline(
                left,
                y + INVENTORY_PANEL_Y,
                right - left,
                HEIGHT - INVENTORY_PANEL_Y,
                theme.frameLight()
        );
    }

    private static void tile(
            GuiGraphicsExtractor graphics,
            Identifier texture,
            int x,
            int y,
            int width,
            int height
    ) {
        for (int offsetY = 0; offsetY < height; offsetY += TILE_SIZE) {
            int tileHeight = Math.min(TILE_SIZE, height - offsetY);
            for (int offsetX = 0; offsetX < width; offsetX += TILE_SIZE) {
                int tileWidth = Math.min(TILE_SIZE, width - offsetX);
                graphics.blit(
                        RenderPipelines.GUI_TEXTURED,
                        texture,
                        x + offsetX,
                        y + offsetY,
                        0.0F,
                        0.0F,
                        tileWidth,
                        tileHeight,
                        TILE_SIZE,
                        TILE_SIZE
                );
            }
        }
    }
}
