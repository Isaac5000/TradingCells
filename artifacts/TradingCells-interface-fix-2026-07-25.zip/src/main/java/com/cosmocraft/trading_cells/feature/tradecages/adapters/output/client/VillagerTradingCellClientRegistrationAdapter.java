package com.cosmocraft.trading_cells.feature.tradecages.adapters.output.client;

import com.cosmocraft.trading_cells.feature.tradecages.adapters.output.TradingCellsRegistrationAdapter;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

public final class VillagerTradingCellClientRegistrationAdapter {
    private VillagerTradingCellClientRegistrationAdapter() {
    }

    public static void onRegisterMenuScreens(RegisterMenuScreensEvent event) {
        event.register(
                TradingCellsRegistrationAdapter.VILLAGER_TRADING_CELL_MENU.get(),
                VillagerTradingCellScreen::new
        );
    }
}
