package com.cosmocraft.trading_cells.feature.tradecages.adapters.output;

import com.cosmocraft.trading_cells.feature.tradecages.adapters.input.PiglinBarteringCellBlock;
import com.cosmocraft.trading_cells.feature.tradecages.adapters.input.PiglinBarteringCellBlockEntity;
import com.cosmocraft.trading_cells.feature.tradecages.adapters.input.PiglinBarteringCellBlockItem;
import com.cosmocraft.trading_cells.feature.tradecages.adapters.input.VillagerTradingCellBlock;
import com.cosmocraft.trading_cells.feature.tradecages.adapters.input.VillagerTradingCellBlockEntity;
import com.cosmocraft.trading_cells.feature.tradecages.adapters.input.VillagerTradingCellBlockItem;
import com.cosmocraft.trading_cells.feature.tradecages.adapters.input.VillagerTradingCellMenu;
import com.cosmocraft.trading_cells.platform.neoforge.bootstrap.TradingCells;
import com.cosmocraft.trading_cells.platform.neoforge.machine.MachineBlockProperties;
import com.cosmocraft.trading_cells.platform.neoforge.registration.Registration;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;

@SuppressWarnings("java:S1118")
public class TradingCellsRegistrationAdapter {
    private static final String TRADE_CAGE_ID = "villager_trading_cell";
    private static final String PIGLIN_BARTERING_CELL_ID = "piglin_bartering_cell";

    public static final DeferredBlock<VillagerTradingCellBlock> TRADE_CAGE_BLOCK =
            Registration.BLOCKS.register(TRADE_CAGE_ID, () ->
                    new VillagerTradingCellBlock(MachineBlockProperties.create(TRADE_CAGE_ID))
            );

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<VillagerTradingCellBlockEntity>> VILLAGER_TRADING_CELL_BLOCK_ENTITY =
            Registration.BLOCK_ENTITY_TYPES.register(TRADE_CAGE_ID, () ->
                    new BlockEntityType<>(VillagerTradingCellBlockEntity::new, TRADE_CAGE_BLOCK.get())
            );

    public static final DeferredHolder<MenuType<?>, MenuType<VillagerTradingCellMenu>> VILLAGER_TRADING_CELL_MENU =
            Registration.MENU_TYPES.register(TRADE_CAGE_ID, () ->
                    new MenuType<>(VillagerTradingCellMenu::new, FeatureFlags.VANILLA_SET)
            );

    public static final DeferredBlock<PiglinBarteringCellBlock> PIGLIN_BARTERING_CELL_BLOCK =
            Registration.BLOCKS.register(PIGLIN_BARTERING_CELL_ID, () ->
                    new PiglinBarteringCellBlock(MachineBlockProperties.create(PIGLIN_BARTERING_CELL_ID))
            );

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PiglinBarteringCellBlockEntity>> PIGLIN_BARTERING_CELL_BLOCK_ENTITY =
            Registration.BLOCK_ENTITY_TYPES.register(PIGLIN_BARTERING_CELL_ID, () ->
                    new BlockEntityType<>(PiglinBarteringCellBlockEntity::new, PIGLIN_BARTERING_CELL_BLOCK.get())
            );

    public static final DeferredItem<VillagerTradingCellBlockItem> TRADE_CAGE_ITEM =
            Registration.ITEMS.register(TRADE_CAGE_ID, () -> new VillagerTradingCellBlockItem(
                    TRADE_CAGE_BLOCK.get(),
                    new Item.Properties()
                            .setId(ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(TradingCells.MOD_ID, TRADE_CAGE_ID)))
            ));

    public static final DeferredItem<PiglinBarteringCellBlockItem> PIGLIN_BARTERING_CELL_ITEM =
            Registration.ITEMS.register(PIGLIN_BARTERING_CELL_ID, () -> new PiglinBarteringCellBlockItem(
                    PIGLIN_BARTERING_CELL_BLOCK.get(),
                    new Item.Properties()
                            .setId(ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(TradingCells.MOD_ID, PIGLIN_BARTERING_CELL_ID)))
            ));

    public static void load() {
        // Forces class loading so all DeferredRegister entries are created.
    }
}
