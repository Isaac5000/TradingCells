package com.cosmocraft.trading_cells.feature.incubators.domain.model;

import com.cosmocraft.trading_cells.feature.machines.domain.model.TimedProcess;

public final class IncubationCycle {
    private IncubationCycle() {
    }

    public static TimedProcess.Step advance(
            int currentTicks,
            int durationTicks,
            boolean validBaby,
            boolean outputAvailable
    ) {
        TimedProcess.Availability availability = !validBaby
                ? TimedProcess.Availability.INACTIVE
                : outputAvailable
                        ? TimedProcess.Availability.ACTIVE
                        : TimedProcess.Availability.BLOCKED;
        return TimedProcess.advance(currentTicks, durationTicks, availability);
    }
}
