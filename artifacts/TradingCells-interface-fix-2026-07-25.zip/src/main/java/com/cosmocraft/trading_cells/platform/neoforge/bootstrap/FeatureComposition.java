package com.cosmocraft.trading_cells.platform.neoforge.bootstrap;

import com.cosmocraft.trading_cells.feature.autotrader.application.port.input.AutotraderUseCase;
import com.cosmocraft.trading_cells.feature.autotrader.application.service.AutotraderService;
import com.cosmocraft.trading_cells.feature.breeders.application.port.input.BreederUseCase;
import com.cosmocraft.trading_cells.feature.breeders.application.service.BreederService;
import com.cosmocraft.trading_cells.feature.converter.application.port.input.ConverterUseCase;
import com.cosmocraft.trading_cells.feature.converter.application.service.ConverterService;
import com.cosmocraft.trading_cells.feature.farmer.application.port.input.FarmerUseCase;
import com.cosmocraft.trading_cells.feature.farmer.application.service.FarmerService;
import com.cosmocraft.trading_cells.feature.incubators.application.port.input.IncubatorUseCase;
import com.cosmocraft.trading_cells.feature.incubators.application.service.IncubatorService;
import com.cosmocraft.trading_cells.feature.ironfarm.application.port.input.IronFarmUseCase;
import com.cosmocraft.trading_cells.feature.ironfarm.application.service.IronFarmService;
import com.cosmocraft.trading_cells.feature.tradecages.application.port.input.TradeCageUseCase;
import com.cosmocraft.trading_cells.feature.tradecages.application.service.VillagerTradeService;
import com.cosmocraft.trading_cells.platform.neoforge.config.MachineSettingsProvider;

/** NeoForge composition root for feature use cases. */
public final class FeatureComposition {
    private FeatureComposition() {
    }

    public static AutotraderUseCase autotrader() {
        return new AutotraderService(MachineSettingsProvider.values());
    }

    public static BreederUseCase breeder() {
        return new BreederService(MachineSettingsProvider.values());
    }

    public static ConverterUseCase converter() {
        return new ConverterService(MachineSettingsProvider.values());
    }

    public static FarmerUseCase farmer() {
        return new FarmerService(MachineSettingsProvider.values());
    }

    public static IncubatorUseCase incubator() {
        return new IncubatorService(MachineSettingsProvider.values());
    }

    public static IronFarmUseCase ironFarm() {
        return new IronFarmService(MachineSettingsProvider.values());
    }

    public static TradeCageUseCase tradeCage() {
        return new VillagerTradeService(MachineSettingsProvider.values());
    }
}
